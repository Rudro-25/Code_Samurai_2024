# CS24-p2-TeamDateExpired

FrontEnd is hosted on : localhost://3000
BackEnd is hosted on : localhost://8000

Admin Master Password:

    Email       : admin@gmail.com
    Password    : 123123