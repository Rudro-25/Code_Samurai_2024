const e = require('express');
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require("cors");

const port = 8000;
app.use(express.json());
app.use(cors());

mongoose.connect('mongodb+srv://rumman:codesamurai123123@cluster0.e1ywht2.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(async () => {
        app.listen(port, () => {
            console.log(`Server is running on http://localhost:${port}`);
        });
    })
    .catch((err) => console.error('Error connecting to MongoDB:', err));

app.get('/', async (req, res) => {
    try {
        res.send("hello")

    } catch (error) {
    }
});

//_________________________________________________

// ____API_____

//_Authentication_

//_User_

//create User
app.post('/createUser', async (req, res) => {
    try {
        // Create a new user based on request body
        const newUser = new User(req.body);
        // Save the user to the database
        await newUser.save();
        // Send success response
        res.status(201).json({ message: 'User created successfully', user: newUser });
    } catch (error) {
        // If an error occurs during creation, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while creating the user' });
    }
});

//User List

app.get('/userList', async (req, res) => {
    try {
        // Fetch all users from the database
        const users = await User.find().populate("userRoleId");
        // Send the users as response
        res.status(200).json(users);
    } catch (error) {
        // If an error occurs during retrieval, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while fetching users' });
    }
});

//User By Id
app.get('/users/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        // Find the user by ID
        const user = await User.findById(userId).populate("userRoleId");
        // If user is not found, send 404 response
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        // If user is found, send user data
        res.status(200).json(user);
    } catch (error) {
        // If an error occurs during retrieval, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while fetching the user' });
    }
});

//Update User
app.put('/updateUsers/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const { name, email, userRoleId } = req.body;

        // Find the user by ID
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Update user fields
        user.name = name;
        user.email = email;
        user.userRoleId = userRoleId;

        // Save the updated user
        await user.save();

        // Send success response
        res.status(200).json({ message: 'User updated successfully', user });
    } catch (error) {
        // If an error occurs during update, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while updating the user' });
    }
});


//Delete User
app.delete('/deleteUser/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        // Find the user by ID and delete it
        await User.findByIdAndDelete(userId);
        // Send success response
        res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
        // If an error occurs during deletion, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while deleting the user' });
    }
});

//Login 

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        // Find the user by email
        const user = await User.findOne({ email }).populate("userRoleId");
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Check if the password is correct
        if (password !== user.password) {
            return res.status(401).json({ error: 'Invalid password' });
        }
        // If authentication is successful, send success response
        res.status(200).json({ message: 'Login successful', user });
    } catch (error) {
        // If an error occurs during authentication, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while logging in' });
    }
});

//Sign Up
app.post('/signUp', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        // Check if the email is already registered
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: 'Email already exists' });
        }
        // Create a new user
        const newUser = new User({ name, email, password });
        // Save the user to the database
        await newUser.save();
        // Send success response
        res.status(201).json({ message: 'User registered successfully', user: newUser });
    } catch (error) {
        // If an error occurs during registration, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while registering the user' });
    }
});

//Create User Role
app.post("/createUserRole", async (req, res) => {
    try {
        // Create a new instance of UserRole model using the request body
        const newUserRole = new Role(req.body);

        // Save the new user role to the database
        await newUserRole.save();

        // Respond with a success message or any relevant data
        res.status(200).json({ message: "User role saved successfully", newUserRole });
    } catch (error) {
        // If an error occurs during processing, handle it here
        console.error("Error:", error);
        // Respond with an error message
        res.status(500).json({ error: "An error occurred while processing your request" });
    }
});

//Get User Roles
app.get('/userRoles', async (req, res) => {
    try {
        // Fetch all user roles from the database
        const userRoles = await Role.find();
        // Send the user roles as response
        res.status(200).json(userRoles);
    } catch (error) {
        // If an error occurs during retrieval, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while fetching user roles' });
    }
});

//_STS_
//_Landfill_
//_Bill_

//_________________________________________________


// _____Models_____

// User
const userSchema = new mongoose.Schema({
    name: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },
    userRoleId: {
        type: mongoose.Types.ObjectId,
        ref: "RoleModel"
    }
});

const User = new mongoose.model('UserModel', userSchema);


// User Role
const userRoleSchema = new mongoose.Schema({
    name: {
        type: String
    },
    permissions: [
        {
            type: Number
        }
    ]
})

const Role = new mongoose.model("RoleModel", userRoleSchema);

// Permission

const PermissionSchema = new mongoose.Schema({
    name: {
        type: String
    }
})

const Permission = new mongoose.model("PermissionModel", PermissionSchema);

// Secondary Transfer Station(STS)

const stsSchema = new mongoose.Schema({
    ward: {
        type: Number
    },
    capacity: {
        type: Number
    },
    latitude: {
        type: String
    },
    longitude: {
        type: String
    },
    managers: [
        {
            type: mongoose.Types.ObjectId,
            ref: "UserModel"
        }
    ],
    vehicles: [
        {
            type: mongoose.Types.ObjectId,
            ref: "vehicleModel"
        }
    ]
})

const STS = new mongoose.model("stsModel", stsSchema);

// Landfill Site

const landfillSiteSchema = new mongoose.Schema({
    capacity: {
        type: Number
    },
    operationTime: {
        type: Date
    },
    latitude: {
        type: String
    },
    longitude: {
        type: String
    },
    managers: [
        {
            type: mongoose.Types.ObjectId,
            ref: "UserModel"
        }
    ]
})

const LandfillSite = new mongoose.model("ladnfillSiteModel", landfillSiteSchema);


// Vehicle

const vehicleSchema = new mongoose.Schema({
    registrationNumber: {
        type: String
    },
    type: {
        type: Number
    },
    capacity: {
        type: Number
    },
    costLoaded: {
        type: Number
    },
    costUnloaded: {
        type: Number
    },
    sts: {
        type: mongoose.Types.ObjectId,
        ref: "stsModel"
    }
})

const Vehicle = new mongoose.model("vehicleModel", vehicleSchema);

// Vehicle Type

const vehicleTypeSchema = new mongoose.Schema({
    name: {
        type: String
    }
})

const VehicleType = new mongoose.model("vehicleTypeModel", vehicleTypeSchema);

// Vehicle Logbook STS

const vehicleLogbookStsSchema = new mongoose.Schema({
    sts: {
        type: mongoose.Types.ObjectId,
        ref: "stsModel"
    },
    vehicle: {
        type: Number
    },
    weightWaste: {
        type: Number
    },
    arrivalTime: {
        type: Date
    },
    departureTime: {
        type: Date
    }

})

const VehicleLogbookSTS = new mongoose.model("vehicleLogbookStsModel", vehicleLogbookStsSchema)

// Vehicle Logbook Landfill Site

const vehicleLogbookLandfillSiteSchema = new mongoose.Schema({
    landfill: {
        type: mongoose.Types.ObjectId,
        ref: "ladnfillSiteModel"
    },
    vehicle: {
        type: mongoose.Types.ObjectId,
        ref: "vehicleTypeModel"
    },
    weightWaste: {
        type: Number
    },
    arrivalTime: {
        type: Date
    },
    departureTime: {
        type: Date
    }

})

const VehicleLogbookLandfillSite = new mongoose.model("vehicleLogbookLandfillSiteModel", vehicleLogbookLandfillSiteSchema)

// Bill

const billSchema = new mongoose.Schema({
    time: {
        type: Date
    },
    wasteWeight: {
        type: Number
    },
    vehicle: {
        type: mongoose.Types.ObjectId,
        ref: "vehicleTypeModel"
    },
    fuel: {
        type: Number
    },
    cost: {
        type: Number
    }
})

const Bill = new mongoose.model("billModel", billSchema)