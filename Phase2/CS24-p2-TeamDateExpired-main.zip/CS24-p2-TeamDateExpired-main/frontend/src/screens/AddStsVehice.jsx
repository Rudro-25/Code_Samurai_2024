import React, { useState } from 'react';
import './AddVehicleEntryPage.css';

function AddVehicleEntryPage() {
  const [stsId, setStsId] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [weightOfWaste, setWeightOfWaste] = useState('');
  const [arrivalTime, setArrivalTime] = useState('');
  const [departureTime, setDepartureTime] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with stsId:", stsId, "vehicleNumber:", vehicleNumber, "weightOfWaste:", weightOfWaste, "arrivalTime:", arrivalTime, "departureTime:", departureTime);
  };

  return (
    <div className="add-vehicle-entry-page-container">
      <h2>Add Entry of Vehicle Leaving STS</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="stsId">STS ID:</label>
          <input
            type="text"
            id="stsId"
            value={stsId}
            onChange={(e) => setStsId(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="vehicleNumber">Vehicle Number:</label>
          <input
            type="text"
            id="vehicleNumber"
            value={vehicleNumber}
            onChange={(e) => setVehicleNumber(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="weightOfWaste">Weight of Waste:</label>
          <input
            type="text"
            id="weightOfWaste"
            value={weightOfWaste}
            onChange={(e) => setWeightOfWaste(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="arrivalTime">Time of Arrival:</label>
          <input
            type="text"
            id="arrivalTime"
            value={arrivalTime}
            onChange={(e) => setArrivalTime(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="departureTime">Time of Departure:</label>
          <input
            type="text"
            id="departureTime"
            value={departureTime}
            onChange={(e) => setDepartureTime(e.target.value)}
            required
          />
        </div>
        <button type="submit">Add Entry</button>
      </form>
    </div>
  );
}

export default AddVehicleEntryPage;
