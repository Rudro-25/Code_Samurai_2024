import React, { useEffect, useState } from 'react'
import "./CreateUser.css"
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function CreateUser() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [userRole, setUserRole] = useState('');

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleUserRoleChange = (e) => {
    setUserRole(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic\
    axios.post("http://localhost:8000/createUser", {
      name: name,
      email: email,
      password: password,
      userRoleId: userRole
    }).then(function (response) {
      // handle success
      console.log(response);
      setName('')
      setEmail('')
      setPassword('')
      setUserRole('')
      navigate('/adminHome')
    })
      .catch(function (error) {
        // handle error
        console.log(error);
      })
    console.log("Submitting form with:", name, email, password, userRole);
  };
  return (
    <div className="registration-container">
      <h2>Create An User</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={handleNameChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={handleEmailChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={handlePasswordChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="userRole">User Role:</label>
          <select id="userRole" value={userRole} onChange={handleUserRoleChange} required>
            <option value="">Select User Role</option>
            <option value="66093a2afcabfed766820639">Admin</option>
            <option value="66093a31fcabfed76682063b">STS Manager</option>
            <option value="66093a38fcabfed76682063d">Landfill Manager</option>
          </select>
        </div>
        <button type="submit">Register</button>
      </form>
    </div>
  )
}
