import React, { useState } from 'react'
import "./AdminHome.css"
import { useNavigate } from 'react-router-dom';


export const AdminHome = () => {
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = () => {
    // Handle logout logic
    console.log("Logging out...");
    navigate("/")
  };

  return (
    <div className="admin-home-page">
      <nav className="navbar">
        <div className="navbar-left">
          <h1>Admin Home</h1>
        </div>
        <div className="navbar-right">
          <div className="profile-icon" onClick={toggleDropdown}>
            <span>Profile</span>
            {isDropdownOpen && (
              <div className="dropdown-content">
                <a href="#">Profile</a>
                <a href="#" onClick={handleLogout}>Log Out</a>
              </div>
            )}
          </div>
        </div>
      </nav>
      <div className="admin-content">
        <div className="box manage-sts" onClick={() => navigate('/createRole')}>
          <h2>Create Role</h2>
        </div>
        <div className="box manage-landfill" onClick={() => navigate('/createUser')}>
          <h2>Create User</h2>
        </div>
        <div className="box manage-users" onClick={() => navigate('/userList')}>
          <h2>User List</h2>
        </div>
        <div className="box dashboard-statistics">
          <h2>Dashboard Statistics</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/createPermissoin')}>
          <h2>Create Permissions</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/addVehicle')}>
          <h2>Add Vehicle</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/createSts')}>
          <h2>Create STS</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/assignStsMngr')}>
          <h2>Assign Manager to STS</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/assignTrckSts')}>
          <h2>Assign Trucks To STS</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/createLandfillSite')}>
          <h2>Create Landfill Site</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/assignLndflMngr')}>
          <h2>Assign Landfill To Manager</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/addVehicleSts')}>
          <h2>Add Vechicle To STS</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/stsList')}>
          <h2>STS List</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/landfillList')}>
          <h2>Landfill List</h2>
        </div>
        <div className="box dashboard-statistics" onClick={() => navigate('/vehicleLIst')}>
          <h2>Vehicle List</h2>
        </div>
      </div>
    </div>
  )
}
