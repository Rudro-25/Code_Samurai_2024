import React, { useState } from 'react';
import './AssignSTSManagerPage.css';

function AssignSTSManagerPage() {
  const [stsId, setStsId] = useState('');
  const [managerIds, setManagerIds] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with stsId:", stsId, "managerIds:", managerIds);
  };

  return (
    <div className="assign-sts-manager-page-container">
      <h2>Assign STS Managers</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="stsId">STS ID:</label>
          <input
            type="text"
            id="stsId"
            value={stsId}
            onChange={(e) => setStsId(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="managerIds">STS Manager IDs (comma-separated):</label>
          <input
            type="text"
            id="managerIds"
            value={managerIds}
            onChange={(e) => setManagerIds(e.target.value.split(",").map(id => id.trim()))}
            required
          />
        </div>
        <button type="submit">Assign Managers</button>
      </form>
    </div>
  );
}

export default AssignSTSManagerPage;
