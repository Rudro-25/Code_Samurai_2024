import React, { useState } from 'react';
import './CreateSTSPage.css';

function CreateSTSPage() {
  const [wardNumber, setWardNumber] = useState('');
  const [capacity, setCapacity] = useState('');
  const [coordinates, setCoordinates] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with wardNumber:", wardNumber, "capacity:", capacity, "coordinates:", coordinates);
  };

  return (
    <div className="create-sts-page-container">
      <h2>Create STS</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="wardNumber">Ward Number:</label>
          <input
            type="text"
            id="wardNumber"
            value={wardNumber}
            onChange={(e) => setWardNumber(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="capacity">Capacity (in Tonnes):</label>
          <input
            type="text"
            id="capacity"
            value={capacity}
            onChange={(e) => setCapacity(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="coordinates">GPS Coordinates:</label>
          <input
            type="text"
            id="coordinates"
            value={coordinates}
            onChange={(e) => setCoordinates(e.target.value)}
            required
          />
        </div>
        <button type="submit">Create STS</button>
      </form>
    </div>
  );
}

export default CreateSTSPage;
