import React from 'react';
import './STSListPage.css';

// Sample data for STS list
const stsListData = [
  { id: 1, name: 'STS 1', ward: 'Ward 1', capacity: '10', location: 'Coordinates 1', managers: ['Manager 1', 'Manager 2'], trucks: ['Truck 1', 'Truck 2'] },
  { id: 2, name: 'STS 2', ward: 'Ward 2', capacity: '15', location: 'Coordinates 2', managers: ['Manager 3', 'Manager 4'], trucks: ['Truck 3', 'Truck 4'] },
  // Add more data as needed
];

function STSListPage() {
  const handleEdit = (id) => {
    // Handle edit action
    console.log("Editing STS with id:", id);
  };

  const handleDelete = (id) => {
    // Handle delete action
    console.log("Deleting STS with id:", id);
  };

  return (
    <div className="sts-list-page-container">
      <h2>STS List</h2>
      <table className="sts-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Ward</th>
            <th>Capacity</th>
            <th>Location</th>
            <th>Manager List</th>
            <th>Truck List</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {stsListData.map(sts => (
            <tr key={sts.id}>
              <td>{sts.name}</td>
              <td>{sts.ward}</td>
              <td>{sts.capacity}</td>
              <td>{sts.location}</td>
              <td>{sts.managers.join(', ')}</td>
              <td>{sts.trucks.join(', ')}</td>
              <td>
                <button onClick={() => handleEdit(sts.id)}>Edit</button>
                <button onClick={() => handleDelete(sts.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default STSListPage;
