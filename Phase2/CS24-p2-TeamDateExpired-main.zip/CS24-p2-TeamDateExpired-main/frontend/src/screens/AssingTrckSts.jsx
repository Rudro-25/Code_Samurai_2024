import React, { useState } from 'react';
import './AssignTrucksToSTSPage.css';

function AssignTrucksToSTSPage() {
  const [stsId, setStsId] = useState('');
  const [truckIds, setTruckIds] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with stsId:", stsId, "truckIds:", truckIds);
  };

  return (
    <div className="assign-trucks-to-sts-page-container">
      <h2>Assign Trucks to STS</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="stsId">STS ID:</label>
          <input
            type="text"
            id="stsId"
            value={stsId}
            onChange={(e) => setStsId(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="truckIds">Truck IDs (comma-separated):</label>
          <input
            type="text"
            id="truckIds"
            value={truckIds}
            onChange={(e) => setTruckIds(e.target.value.split(",").map(id => id.trim()))}
            required
          />
        </div>
        <button type="submit">Assign Trucks</button>
      </form>
    </div>
  );
}

export default AssignTrucksToSTSPage;
