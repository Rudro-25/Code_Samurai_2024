import React from 'react';
import './VehicleListPage.css';

// Sample data for vehicle list
const vehicleListData = [
  { id: 1, registrationNumber: 'ABC123', type: 'Open Truck', capacity: '3 ton', fuelCostLoaded: '10', fuelCostUnloaded: '5' },
  { id: 2, registrationNumber: 'DEF456', type: 'Dump Truck', capacity: '5 ton', fuelCostLoaded: '12', fuelCostUnloaded: '6' },
  // Add more data as needed
];

function VehicleListPage() {
  const handleUpdate = (id) => {
    // Handle update action
    console.log("Updating vehicle with id:", id);
  };

  const handleDelete = (id) => {
    // Handle delete action
    console.log("Deleting vehicle with id:", id);
  };

  return (
    <div className="vehicle-list-page-container">
      <h2>Vehicle List</h2>
      <table className="vehicle-table">
        <thead>
          <tr>
            <th>Registration Number</th>
            <th>Type</th>
            <th>Capacity</th>
            <th>Fuel Cost (Loaded)</th>
            <th>Fuel Cost (Unloaded)</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {vehicleListData.map(vehicle => (
            <tr key={vehicle.id}>
              <td>{vehicle.registrationNumber}</td>
              <td>{vehicle.type}</td>
              <td>{vehicle.capacity}</td>
              <td>{vehicle.fuelCostLoaded}</td>
              <td>{vehicle.fuelCostUnloaded}</td>
              <td>
                <button onClick={() => handleUpdate(vehicle.id)}>Update</button>
                <button onClick={() => handleDelete(vehicle.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default VehicleListPage;
