import React, { useState } from 'react';
import './CreatePermission.css';

function CreatePermissioin() {
  const [name, setName] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with name:", name);
  };

  return (
    <div className="permission-creation-form-container">
      <h2>Create Permission</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <button type="submit">Create Permission</button>
      </form>
    </div>
  );
}

export default CreatePermissioin;
