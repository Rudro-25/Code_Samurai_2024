import React from "react";
import Login from "./screens/Login";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import SignUp from "./screens/SignUp";
import { AdminHome } from "./screens/AdminHome";
import CreateUser from "./screens/CreateUser";
import LandfillManagerHome from "./screens/LandfillManagerHome";
import StsManagerHome from "./screens/StsManagerHome";
import UserLIst from "./screens/UserLIst";
import UpdateUser from "./screens/UpdateUser";
import CreateRole from "./screens/CreateRole";
import UpdateRoles from "./screens/UpdateRoles";
import CreatePermissioin from "./screens/CreatePermissioin";
import AddVehiclePage from "./screens/AddVehicle";
import CreateSTSPage from "./screens/CreateSts";
import AssignSTSManagerPage from "./screens/AssignStsManager";
import AssignTrucksToSTSPage from "./screens/AssingTrckSts";
import CreateLandfillSitePage from "./screens/CreateLandfillSite";
import AssignLandfillManagerPage from "./screens/AssingLndfMngr";
import STSListPage from "./screens/StsList";
import LandfillListPage from "./screens/LanfFillLIstPage";
import VehicleListPage from "./screens/VehicleLIst";

function App() {
  const route = createBrowserRouter([
    {
      path: "/",
      element: <Login />
    },
    {
      path: "/signUp",
      element: <SignUp />
    },
    {
      path: "/adminHome",
      element: <AdminHome />
    },
    {
      path: "/createUser",
      element: <CreateUser />
    },
    {
      path: "/landfillManagerHome",
      element: <LandfillManagerHome />
    },
    {
      path: "/stsManagerHome",
      element: <StsManagerHome />
    },
    {
      path: "/userList",
      element: <UserLIst />
    },
    {
      path: "/updateUser/:userId",
      element: <UpdateUser />
    },
    {
      path: "/createRole",
      element: <CreateRole />
    },
    {
      path: "/updateRole/:roleId",
      element: <UpdateRoles />
    },
    {
      path: "/createPermissoin",
      element: <CreatePermissioin />
    },
    {
      path: "/addVehicle",
      element: <AddVehiclePage />
    },
    {
      path: "/createSts",
      element: < CreateSTSPage/>
    },
    {
      path: "/assignStsMngr",
      element: < AssignSTSManagerPage/>
    },
    {
      path: "/assignTrckSts",
      element: < AssignTrucksToSTSPage/>
    },
    {
      path: "/createLandfillSite",
      element: < CreateLandfillSitePage/>
    },
    {
      path: "/assignLndflMngr",
      element: < AssignLandfillManagerPage />
    },

    {
      path: "/addVehicleSts",
      element: < AddVehiclePage/>
    },
    {
      path: "/stsList",
      element: < STSListPage/>
    },
    {
      path: "/landfillList",
      element: < LandfillListPage/>
    },
    {
      path: "/vehicleLIst",
      element: < VehicleListPage/>
    },
  
  ])
  return (
    <>
      <RouterProvider router={route} />
    </>
  );
}

export default App;
