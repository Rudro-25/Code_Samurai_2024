const e = require('express');
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require("cors");

const port = 8000;
app.use(express.json());
app.use(cors());

mongoose.connect('mongodb+srv://rumman:codesamurai123123@cluster0.e1ywht2.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(async () => {
        app.listen(port, () => {
            console.log(`Server is running on http://localhost:${port}`);
        });
    })
    .catch((err) => console.error('Error connecting to MongoDB:', err));

app.get('/', async (req, res) => {
    try {
        res.send("hello")

    } catch (error) {
    }
});

//_________________________________________________

// ____API_____

//_Authentication_


//Create Post



// Endpoint to create a new post
app.post('/posts', async (req, res) => {
    const { postText, type } = req.body;

    // Check if required fields are provided
    if (!postText || !type) {
        return res.status(400).json({ message: 'Please provide postText and type' });
    }

    try {
        // Create a new post object
        const newPost = new Post({
            postText,
            type,
            likeCount: 0 // Initial like count is set to 0
        });

        // Save the new post to the database
        await newPost.save();

        // Send a response with the newly created post
        res.status(201).json(newPost);
    } catch (error) {
        console.error('Error creating post:', error);
        res.status(500).json({ message: 'Failed to create post. Please try again later.' });
    }
});

const complaintSchema = new mongoose.Schema({
    complaintText: {
        type: String,
        required: true
    },
    type: {
        type: String,
        required: true
    }
});

const Complaint = new mongoose.model('Complaint', complaintSchema);

app.post('/complaints', async (req, res) => {
    const { complaintText, type } = req.body;

    console.log(complaintText)

    // Check if required fields are provided
    if (!complaintText || !type) {
        return res.status(400).json({ message: 'Please provide complaintText and type' });
    }

    try {
        // Create a new complaint object
        const newComplaint = new Complaint({
            complaintText,
            type
        });

        // Save the new complaint to the database
        await newComplaint.save();

        // Send a response with the newly created complaint
        res.status(201).json(newComplaint);
    } catch (error) {
        console.error('Error creating complaint:', error);
        res.status(500).json({ message: 'Failed to create complaint. Please try again later.' });
    }
});


app.get('/complaints', async (req, res) => {
    try {
        // Fetch all complaints from the database
        const complaints = await Complaint.find();
        res.json(complaints);
    } catch (error) {
        console.error('Error fetching complaints:', error);
        res.status(500).json({ message: 'Failed to fetch complaints' });
    }
});

const postSchema = new mongoose.Schema({
    postText: {
        type: String,
        required: true
    },
    type: {
        type: String,
        enum: ['anonymous', 'unanonymous'], // Only allow 'anonymous' or 'unanonymous' values
        required: true
    },
    likeCount: {
        type: Number,
        default: 0 // Initial like count is set to 0
    },
    createdAt: {
        type: Date,
        default: Date.now // Automatically set the current date when a new post is created
    }
});

app.get('/posts', async (req, res) => {
    try {
        // Fetch all posts from the database
        const posts = await Post.find();

        // Send the posts as a JSON response
        res.json(posts);
    } catch (error) {
        // If an error occurs, send an error response
        console.error('Error fetching posts:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Create a Post model from the schema
const Post = new mongoose.model('Post', postSchema);

//_User_

//create User
app.post('/createUser', async (req, res) => {
    try {
        // Create a new user based on request body
        const newUser = new User(req.body);
        // Save the user to the database
        await newUser.save();
        // Send success response
        res.status(201).json({ message: 'User created successfully', user: newUser });
    } catch (error) {
        // If an error occurs during creation, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while creating the user' });
    }
});

//User List

app.get('/userList', async (req, res) => {
    try {
        // Fetch all users from the database
        const users = await User.find().populate("userRoleId");
        // Send the users as response
        res.status(200).json(users);
    } catch (error) {
        // If an error occurs during retrieval, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while fetching users' });
    }
});

//User By Id
app.get('/users/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        // Find the user by ID
        const user = await User.findById(userId).populate("userRoleId");
        // If user is not found, send 404 response
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        // If user is found, send user data
        res.status(200).json(user);
    } catch (error) {
        // If an error occurs during retrieval, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while fetching the user' });
    }
});

//Update User
app.put('/updateUsers/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const { name, email, userRoleId } = req.body;

        // Find the user by ID
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Update user fields
        user.name = name;
        user.email = email;
        user.userRoleId = userRoleId;

        // Save the updated user
        await user.save();

        // Send success response
        res.status(200).json({ message: 'User updated successfully', user });
    } catch (error) {
        // If an error occurs during update, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while updating the user' });
    }
});


//Delete User
app.delete('/deleteUser/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        // Find the user by ID and delete it
        await User.findByIdAndDelete(userId);
        // Send success response
        res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
        // If an error occurs during deletion, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while deleting the user' });
    }
});

//Login 

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        // Find the user by email
        const user = await User.findOne({ email }).populate("userRoleId");
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Check if the password is correct
        if (password !== user.password) {
            return res.status(401).json({ error: 'Invalid password' });
        }
        // If authentication is successful, send success response
        res.status(200).json({ message: 'Login successful', user });

    } catch (error) {
        // If an error occurs during authentication, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while logging in' });
    }
});

//Sign Up
app.post('/signUp', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        // Check if the email is already registered
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: 'Email already exists' });
        }
        // Create a new user
        const newUser = new User({ name, email, password });
        // Save the user to the database
        await newUser.save();
        // Send success response
        res.status(201).json({ message: 'User registered successfully', user: newUser });
    } catch (error) {
        // If an error occurs during registration, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while registering the user' });
    }
});

//Create User Role
app.post("/createUserRole", async (req, res) => {
    try {
        // Create a new instance of UserRole model using the request body
        const newUserRole = new Role(req.body);

        // Save the new user role to the database
        await newUserRole.save();

        // Respond with a success message or any relevant data
        res.status(200).json({ message: "User role saved successfully", newUserRole });
    } catch (error) {
        // If an error occurs during processing, handle it here
        console.error("Error:", error);
        // Respond with an error message
        res.status(500).json({ error: "An error occurred while processing your request" });
    }
});

//Get User Roles
app.get('/userRoles', async (req, res) => {
    try {
        // Fetch all user roles from the database
        const userRoles = await Role.find();
        // Send the user roles as response
        res.status(200).json(userRoles);
    } catch (error) {
        // If an error occurs during retrieval, send error response
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred while fetching user roles' });
    }
});

//_STS_
//createSts
app.post('/sts', async (req, res) => {
    const { ward, capacity, latitude, longitude } = req.body;

    try {
        // Create a new STS entry
        const newSTS = await STS.create({
            ward,
            capacity,
            latitude,
            longitude
        });

        res.status(201).json({ message: "STS entry created successfully", sts: newSTS });
    } catch (error) {
        res.status(500).json({ error: "Failed to create STS entry", details: error.message });
    }
});

//stsList

app.get('/sts', async (req, res) => {
    try {
        // Retrieve all STS entries from the database
        const allSTS = await STS.find();

        res.status(200).json(allSTS);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch STS entries", details: error.message });
    }
});

//_Landfill_
//_Bill_
//_Vehicle
app.post('/creaetVehicles', async (req, res) => {
    try {
        // Create a new vehicle object based on the request body
        const newVehicle = new Vehicle({
            registrationNumber: req.body.registrationNumber,
            type: req.body.type,
            capacity: req.body.capacity,
            costLoaded: req.body.costLoaded,
            costUnloaded: req.body.costUnloaded,
            sts: req.body.sts
        });

        // Save the new vehicle to the database
        const savedVehicle = await newVehicle.save();

        res.status(201).json(savedVehicle);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

//_Contractor

//createContractor
app.post('/createContractor', async (req, res) => {
    try {
        // Create a new contractor object based on the request body
        const newContractor = new Contractor({
            name: req.body.name,
            contractId: req.body.contractId,
            regId: req.body.regId,
            regDate: req.body.regDate,
            tin: req.body.tin,
            phone: req.body.phone,
            workforcesSize: req.body.workforcesSize,
            pmntPrTnWst: req.body.pmntPrTnWst,
            rqrdWstPrDay: req.body.rqrdWstPrDay,
            cntrctDur: req.body.cntrctDur,
            areaOfCllctn: req.body.areaOfCllctn,
            sts: req.body.sts
        });

        // Save the new contractor to the database
        const savedContractor = await newContractor.save();

        res.status(201).json(savedContractor);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

//contractorById

app.get('/contractor/:id', async (req, res) => {
    try {
        // Extract the contractor ID from the request parameters
        const contractorId = req.params.id;

        // Find the contractor by ID in the database
        const contractor = await Contractor.findById(contractorId);

        // If contractor is not found, return 404 Not Found
        if (!contractor) {
            return res.status(404).json({ message: 'Contractor not found' });
        }

        // If contractor is found, return it in the response
        res.json(contractor);
    } catch (err) {
        // If there's an error, return 400 Bad Request with the error message
        res.status(400).json({ message: err.message });
    }
});

//contractorList

app.get('/contractors', async (req, res) => {
    try {
        // Retrieve all contractors from the database
        const contractors = await Contractor.find();

        // Return the list of contractors in the response
        res.json(contractors);
    } catch (err) {
        // If there's an error, return 400 Bad Request with the error message
        res.status(400).json({ message: err.message });
    }
});

//updateContractor

app.put('/contractor/:id', async (req, res) => {
    try {
        // Extract the contractor ID from the request parameters
        const contractorId = req.params.id;

        // Find the contractor by ID in the database
        let contractor = await Contractor.findById(contractorId);

        // If contractor is not found, return 404 Not Found
        if (!contractor) {
            return res.status(404).json({ message: 'Contractor not found' });
        }

        // Update the contractor with data from the request body
        contractor.set(req.body);

        // Save the updated contractor to the database
        contractor = await contractor.save();

        // Return the updated contractor in the response
        res.json(contractor);
    } catch (err) {
        // If there's an error, return 400 Bad Request with the error message
        res.status(400).json({ message: err.message });
    }
});

//contractorManager
app.post('/createContractorManager', async (req, res) => {
    try {
        // Create a new contractor manager object based on the request body
        const newContractorManager = new ContractorManager({
            fullName: req.body.fullName,
            userId: req.body.userId,
            emailAddress: req.body.emailAddress,
            contactNumber: req.body.contactNumber,
            assignedContractorCompany: req.body.assignedContractorCompany,
            accessLevel: req.body.accessLevel,
            username: req.body.username,
            password: req.body.password
        });

        // Save the new contractor manager to the database
        const savedContractorManager = await newContractorManager.save();

        res.status(201).json(savedContractorManager);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

//contractorManagerList

app.get('/contractorManagers', async (req, res) => {
    try {
        // Fetch the list of contractor managers from the database
        const contractorManagers = await ContractorManager.find();

        // Return the list of contractor managers in the response
        res.json(contractorManagers);
    } catch (error) {
        // If there's an error, return a 500 Internal Server Error response
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

//workerCreate

app.post('/createEmployee', async (req, res) => {
    try {
        // Create a new employee object based on the request body
        const newEmployee = new Employee({
            employeeId: req.body.employeeId,
            fullName: req.body.fullName,
            dateOfBirth: req.body.dateOfBirth,
            dateOfHire: req.body.dateOfHire,
            jobTitle: req.body.jobTitle,
            paymentRatePerHour: req.body.paymentRatePerHour,
            contactInformation: req.body.contactInformation,
            assignedCollectionRoute: req.body.assignedCollectionRoute
        });

        // Save the new employee to the database
        const savedEmployee = await newEmployee.save();

        res.status(201).json(savedEmployee);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

//workerList

app.get('/employees', async (req, res) => {
    try {
        // Fetch the list of employees from the database
        const employees = await Employee.find();

        // Return the list of employees in the response
        res.json(employees);
    } catch (error) {
        // If there's an error, return a 500 Internal Server Error response
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

//getWorkerById

app.get('/employees/:id', async (req, res) => {
    try {
        // Extract the employee ID from the request parameters
        const employeeId = req.params.id;

        // Fetch the employee from the database by ID
        const employee = await Employee.findById(employeeId);

        // If employee is not found, return a 404 Not Found response
        if (!employee) {
            return res.status(404).json({ message: 'Employee not found' });
        }

        // Return the employee in the response
        res.json(employee);
    } catch (error) {
        // If there's an error, return a 500 Internal Server Error response
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

//workHourMonitor
app.post('/workhourlogs', async (req, res) => {
    const { workerId, logInTime, logOutTime, overtimeHours, absentDays, leaveDays } = req.body;

    try {
        // Create a new work hour log entry
        const newLog = await WorkHourMonitor.create({
            workerId,
            logInTime,
            logOutTime,
            overtimeHours,
            absentDays,
            leaveDays
        });

        res.status(201).json({ message: "Work hour log created successfully", workHourLog: newLog });
    } catch (error) {
        res.status(500).json({ error: "Failed to create work hour log entry", details: error.message });
    }
});

//workHourLogList

app.get('/workhourlogs', async (req, res) => {
    try {
        // Retrieve all work hour logs from the database
        const workHourLogs = await WorkHourMonitor.find();

        res.status(200).json(workHourLogs);
    } catch (error) {
        res.status(500).json({ error: "Failed to retrieve work hour logs", details: error.message });
    }
});

//stsEntry
app.post('/stsentries', async (req, res) => {
    const { timeAndDateOfCollection, amountOfWasteCollected, contractorId, typeOfWasteCollected, designatedSTS } = req.body;

    try {
        // Create a new STS entry
        const newSTSEntry = await STSEntry.create({
            timeAndDateOfCollection,
            amountOfWasteCollected,
            contractorId,
            typeOfWasteCollected,
            designatedSTS
        });

        res.status(201).json({ message: "STS entry created successfully", stsEntry: newSTSEntry });
    } catch (error) {
        res.status(500).json({ error: "Failed to create STS entry", details: error.message });
    }
});

//stsEntriesList

app.get('/stsentries', async (req, res) => {
    try {
        // Retrieve all STS entries from the database
        const allSTSEntries = await STSEntry.find();

        res.status(200).json(allSTSEntries);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch STS entries", details: error.message });
    }
});

//billView

app.get('/billView', async (req, res) => {
    try {
        const contractors = await Contractor.aggregate([
            {
                $lookup: {
                    from: 'stsentries', // Collection name of STSEntry model
                    localField: '_id',
                    foreignField: 'contractorId',
                    as: 'stsentries',
                },
            },
            {
                $project: {
                    contractId: 1,
                    pmntPrTnWst: 1,
                    rqrdWstPrDay: 1,
                    amountOfWasteCollected: '$stsentries.amountOfWasteCollected',
                },
            },
        ]);

        console.log('Contractors:', contractors);

        res.json(contractors);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});



//_________________________________________________


// _____Models_____

// User
const userSchema = new mongoose.Schema({
    name: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },
    userRoleId: {
        type: mongoose.Types.ObjectId,
        ref: "RoleModel"
    }
});

const User = new mongoose.model('UserModel', userSchema);


// User Role
const userRoleSchema = new mongoose.Schema({
    name: {
        type: String
    },
    permissions: [
        {
            type: Number
        }
    ]
})

const Role = new mongoose.model("RoleModel", userRoleSchema);

// Permission

const PermissionSchema = new mongoose.Schema({
    name: {
        type: String
    }
})

const Permission = new mongoose.model("PermissionModel", PermissionSchema);

// Secondary Transfer Station(STS)

const stsSchema = new mongoose.Schema({
    ward: {
        type: Number
    },
    capacity: {
        type: Number
    },
    latitude: {
        type: String
    },
    longitude: {
        type: String
    },
    managers: [
        {
            type: mongoose.Types.ObjectId,
            ref: "UserModel"
        }
    ],
    vehicles: [
        {
            type: mongoose.Types.ObjectId,
            ref: "vehicleModel"
        }
    ]
})

const STS = new mongoose.model("stsModel", stsSchema);

// Landfill Site

const landfillSiteSchema = new mongoose.Schema({
    capacity: {
        type: Number
    },
    operationTime: {
        type: Date
    },
    latitude: {
        type: String
    },
    longitude: {
        type: String
    },
    managers: [
        {
            type: mongoose.Types.ObjectId,
            ref: "UserModel"
        }
    ]
})

const LandfillSite = new mongoose.model("ladnfillSiteModel", landfillSiteSchema);


// Vehicle

const vehicleSchema = new mongoose.Schema({
    registrationNumber: {
        type: String
    },
    type: {
        type: Number
    },
    capacity: {
        type: Number
    },
    costLoaded: {
        type: Number
    },
    costUnloaded: {
        type: Number
    },
    sts: {
        type: mongoose.Types.ObjectId,
        ref: "stsModel"
    }
})

const Vehicle = new mongoose.model("vehicleModel", vehicleSchema);

// Vehicle Type

const vehicleTypeSchema = new mongoose.Schema({
    name: {
        type: String
    }
})

const VehicleType = new mongoose.model("vehicleTypeModel", vehicleTypeSchema);

// Vehicle Logbook STS

const vehicleLogbookStsSchema = new mongoose.Schema({
    sts: {
        type: mongoose.Types.ObjectId,
        ref: "stsModel"
    },
    vehicle: {
        type: Number
    },
    weightWaste: {
        type: Number
    },
    arrivalTime: {
        type: Date
    },
    departureTime: {
        type: Date
    }

})

const VehicleLogbookSTS = new mongoose.model("vehicleLogbookStsModel", vehicleLogbookStsSchema)

// Vehicle Logbook Landfill Site

const vehicleLogbookLandfillSiteSchema = new mongoose.Schema({
    landfill: {
        type: mongoose.Types.ObjectId,
        ref: "ladnfillSiteModel"
    },
    vehicle: {
        type: mongoose.Types.ObjectId,
        ref: "vehicleTypeModel"
    },
    weightWaste: {
        type: Number
    },
    arrivalTime: {
        type: Date
    },
    departureTime: {
        type: Date
    }

})

const VehicleLogbookLandfillSite = new mongoose.model("vehicleLogbookLandfillSiteModel", vehicleLogbookLandfillSiteSchema)

// Bill

const billSchema = new mongoose.Schema({
    time: {
        type: Date
    },
    wasteWeight: {
        type: Number
    },
    vehicle: {
        type: mongoose.Types.ObjectId,
        ref: "vehicleTypeModel"
    },
    fuel: {
        type: Number
    },
    cost: {
        type: Number
    }
})

const Bill = new mongoose.model("billModel", billSchema)

//Contractor

const contractorSchema = new mongoose.Schema({
    name: {
        type: String
    },
    contractId: {
        type: String
    },
    regId: {
        type: String
    },
    regDate: {
        type: Date
    },
    tin: {
        type: String
    },
    phone: {
        type: String
    },
    workforcesSize: {
        type: Number
    },
    pmntPrTnWst: {
        type: Number
    },
    rqrdWstPrDay: {
        type: Number
    },
    cntrctDur: {
        type: String
    },
    areaOfCllctn: [
        {
            type: String
        }
    ],
    sts: {
        type: mongoose.Types.ObjectId,
        ref: "stsModel"
    }

})

const Contractor = new mongoose.model("contractorModel", contractorSchema)

const contractorManagerSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: true
    },
    userId: {
        type: String,
        required: true,
        unique: true
    },
    emailAddress: {
        type: String,
        required: true,
        unique: true
    },
    dateOfAccountCreation: {
        type: Date,
        default: Date.now
    },
    contactNumber: {
        type: String,
        required: true
    },
    assignedContractorCompany: {
        type: String
    },
    accessLevel: {
        type: String,
        enum: ['Level 1', 'Level 2', 'Level 3']
    },
    username: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    }
});

const ContractorManager = new mongoose.model('ContractorManager', contractorManagerSchema);

const employeeSchema = new mongoose.Schema({
    employeeId: {
        type: String,
        required: true,
        unique: true
    },
    fullName: {
        type: String,
        required: true
    },
    dateOfBirth: {
        type: Date,
        required: true
    },
    dateOfHire: {
        type: Date,
        required: true
    },
    jobTitle: {
        type: String,
        required: true
    },
    paymentRatePerHour: {
        type: Number,
        required: true
    },
    contactInformation: {
        type: String,
        required: true
    },
    assignedCollectionRoute: {
        type: String,
        required: true
    }
});

const Employee = new mongoose.model('Employee', employeeSchema);

const WorkHourMonitorSchema = new mongoose.Schema({
    workerId: {
        type: String,
        required: true
    },
    logInTime: {
        type: Date,
        required: true
    },
    logOutTime: {
        type: Date,
        required: true
    },
    overtimeHours: {
        type: Number,
        required: true
    },
    absentDays: {
        type: Number,
        required: true
    },
    leaveDays: {
        type: Number,
        required: true
    }
});

// Create a model based on the schema
const WorkHourMonitor = new mongoose.model('WorkHourMonitor', WorkHourMonitorSchema);

//Monitor Transported Waste By Contractor

const stsEntrySchema = new mongoose.Schema({
    timeAndDateOfCollection: {
        type: Date,
        required: true
    },
    amountOfWasteCollected: {
        type: Number,
        required: true
    },
    contractorId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Contractor',
        required: true
    },
    typeOfWasteCollected: {
        type: String,
        enum: ['Domestic', 'Plastic', 'Construction Waste'],
        required: true
    },
    designatedSTS: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'STS',
        required: true
    },
    /* vehicleUsedForTransportation: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Vehicle',
        required: true
    } */
});

const STSEntry = new mongoose.model('STSEntry', stsEntrySchema);


