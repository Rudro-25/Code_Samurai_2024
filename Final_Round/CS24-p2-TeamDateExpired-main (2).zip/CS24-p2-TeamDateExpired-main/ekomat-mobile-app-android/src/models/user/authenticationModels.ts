export class SignInRequest {
    email?: string;
    password?: string;
}

export class SignUpRequest {
    name?: string;
    email?: string;
    password?: string;
}

export class SendEmailConfirmationCodeRequest {
    emailOrPhone?: string;
}

export class VerifyEmailConfirmationCodeRequest {
    emailOrPhone?: string;
    code?: string;
}

export class SendPhoneConfirmationCodeRequest {
    emailOrPhone?: string;
}

export class VerifyPhoneConfirmationCodeRequest {
    emailOrPhone?: string;
    code?: string;
}

export class ResetPasswordRequest {
    emailOrPhone?: string;
    token?: string;
    newPassword?: string;
    confirmNewPassword?: string;
}