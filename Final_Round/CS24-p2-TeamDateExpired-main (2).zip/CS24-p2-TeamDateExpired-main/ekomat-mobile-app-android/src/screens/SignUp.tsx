import { StyleSheet, Text, View, ScrollView, SafeAreaView } from 'react-native'
import React, { useState } from 'react'
import AppTextInput from '../components/common/AppTextInput'
import { AppTextArea } from '../components/common/AppTextArea';
import { AppButton } from '../components/common/AppButton';
import { SignUpRequest } from '../models/user/authenticationModels';
import { signUpService } from '../services/http/user/authenticationServices';
import axios from 'axios';
import { storeInLocalStorage } from '../components/common/ExpoSecureStore';

const SignUp = ({ navigation }: { navigation: any }) => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [userName, setUserName] = useState('');
    const [emailOrPhone, setEmailOrPhone] = useState('');
    const [about, setAbout] = useState('')
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const handleSubmit = () => {
        const userData = new SignUpRequest

        userData.name = firstName;
        userData.email = emailOrPhone;
        userData.password = password;

        /*  signUpService(userData)
             .then((res: any) => {
                 console.log("signUpResIn", userData)
                 console.log("signUpRes", res.data)
             })
             .catch((err: any) => {
                 console.log("signUpErrIn", userData)
                 console.log("singUpErr", err.response.data)
             }) */

        axios.post('http://192.168.56.1:8000/signUp', userData)
            .then((res: any) => {
                console.log("res", res.data)
                storeInLocalStorage("isLoggedIn", 'true')
                navigation.navigate('profile', { reload: true })
            })
            .catch((err) => {
                console.log("err", err)
            })
    }

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: '#E1EFEC',
                justifyContent: 'center',
                alignItems: 'center',
                paddingTop: 70
            }}
        >
            <Text
                style={{
                    fontSize: 18
                }}
            >
                Sign Up To EcoSync</Text>
            <ScrollView>
                <AppTextInput label='First Name' onChange={(e: any) => setFirstName(e)} />
                <AppTextInput label='Email' onChange={(e: any) => setEmailOrPhone(e)} />
                <AppTextInput type='password' label='Password' onChange={(e: any) => setPassword(e)} />
            </ScrollView>
            <AppButton text='Sign Up' onPress={() => handleSubmit()} />
        </SafeAreaView>
    )
}

export default SignUp