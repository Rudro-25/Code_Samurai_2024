import { Button, SafeAreaView, StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import useGetIsLoogedIn from '../hooks/useGetIsLoggedIn';
import { getIsLoggedIn, getLocalStorageValueByKey, storeInLocalStorage } from '../components/common/ExpoSecureStore';
import { useFocusEffect } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import * as SecureStore from 'expo-secure-store';

const Profile = ({ navigation }: { navigation: any }) => {

    const isFocused = useIsFocused();

    const [toggler, setToggler] = useState(false)

    const isLoggedIn = useGetIsLoogedIn('isLoggedIn', isFocused, toggler);

    const clearIsLoggedIn = () => {
        storeInLocalStorage("isLoggedIn", "false")
        setToggler(!toggler)
    }

    let result = getIsLoggedIn("isLoggedIn");
    console.log('result', result)

    console.log("isLoggedInProfile", isLoggedIn)

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: '#E1EFEC',
            justifyContent: "center",
            alignItems: "center"
        }}>
            {isLoggedIn === 'true' ?
                <View>
                    <Text>You are logged in currently</Text>
                    <Button title='LogOut' onPress={clearIsLoggedIn} />
                </View>
                :
                <View>
                    <Text>You are not logged in currently {'\n'}</Text>
                    <Button title='Sign In' onPress={() => navigation.navigate('signIn')}></Button>
                </View>
            }
        </SafeAreaView>
    )
}

export default Profile
