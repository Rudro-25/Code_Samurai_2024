import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Security = () => {
  return (
    <View>
      <Text>Security</Text>
    </View>
  )
}

export default Security

const styles = StyleSheet.create({})