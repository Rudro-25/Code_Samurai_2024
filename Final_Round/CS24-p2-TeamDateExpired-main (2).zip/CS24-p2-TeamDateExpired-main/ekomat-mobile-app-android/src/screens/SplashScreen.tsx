import { Button, StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SplashScreen = ({navigation}:{navigation:any}) => {
  return (
    <View  style={{flex:1, justifyContent: 'center', alignItems: 'center'}}>
      <Text style={{fontSize:30}}>EcoSync{'\n'}{'\n'}</Text>
      <Button title='Get Started' onPress={() => navigation.navigate('home')}/>
    </View>
  )
}

export default SplashScreen