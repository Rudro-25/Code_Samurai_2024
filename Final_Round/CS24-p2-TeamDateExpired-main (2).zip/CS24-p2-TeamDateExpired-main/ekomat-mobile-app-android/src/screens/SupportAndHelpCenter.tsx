import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SupportAndHelpCenter = () => {
  return (
    <View>
      <Text>SupportAndHelpCenter</Text>
    </View>
  )
}

export default SupportAndHelpCenter

const styles = StyleSheet.create({})