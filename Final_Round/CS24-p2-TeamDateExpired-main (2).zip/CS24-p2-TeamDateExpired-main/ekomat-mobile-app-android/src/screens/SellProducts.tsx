import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SellProducts = () => {
  return (
    <View>
      <Text>SellProducts</Text>
    </View>
  )
}

export default SellProducts

const styles = StyleSheet.create({})