import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AddProduct = () => {
  return (
    <View>
      <Text>AddProduct</Text>
    </View>
  )
}

export default AddProduct

const styles = StyleSheet.create({})