/* import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Button } from 'react-native';
import axios from 'axios';

const Home = ({navigation}:{navigation:any}) => {
  // Bangla post objects related to waste management system of a municipality
  const posts = [
    { id: 1, title: 'বর্ড প্লেসে নিরাপত্তা', content: 'মুসা প্লেসে স্থাপিত নগর পরিষদ নিরাপত্তা' },
    { id: 2, title: 'রাস্তার সাফাই', content: 'গুলসানে আবারও শুরু হলো রাস্তার সাফাই' },
    { id: 3, title: 'বিভিন্ন জেলার সাফাই', content: 'ঢাকার বিভিন্ন জেলার সাফাই চালু হয়েছে' },
    { id: 4, title: 'প্লাস্টিক ব্যবস্থা', content: 'প্লাস্টিক ব্যবস্থা নিয়ে গুলশানে চর্চা' },
    { id: 5, title: 'প্লাস্টিক সংক্রান্ত কার্যক্রম', content: 'প্লাস্টিক সংক্রান্ত কার্যক্রমে বিভিন্ন অনুষ্ঠান আয়োজন' },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      
      <Text style={{ fontSize: 30, paddingTop: 30 }}>EcoSync{'\n'}</Text>
      {posts.map(post => (
        <TouchableOpacity key={post.id} style={styles.post}>
          <Text style={styles.title}>{post.title}</Text>
          <Text style={styles.content}>{post.content}</Text>
          <View style={styles.actions}>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>লাইক</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>মন্তব্য</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      ))}
      <Button title='CreatePost' onPress={()=> navigation.navigate('createPost')}/>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 8,
  },
  post: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  content: {
    fontSize: 16,
    marginBottom: 16,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default Home;
 */

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Button } from 'react-native';
import axios from 'axios';
import { useIsFocused } from '@react-navigation/native';

const Home = ({ navigation }: { navigation: any }) => {

  const isFocused = useIsFocused();
  
  const [posts, setPosts] = useState<any[]>([]);

  useEffect(() => {
    // Fetch posts from API
    const fetchPosts = async () => {
      try {
        const response = await axios.get('http://192.168.56.1:8000/posts');
        setPosts(response.data);
      } catch (error) {
        console.error('Error fetching posts:', error);
      }
    };

    fetchPosts();
  }, [isFocused]);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={{ fontSize: 30, paddingTop: 30 }}>EcoSync{'\n'}</Text>
      {posts.map((post) => (
        <TouchableOpacity key={post._id} style={styles.post}>
          <Text style={styles.title}>{post._id}</Text>
          <Text style={styles.content}>{post.postText}</Text>
          <View style={styles.actions}>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>Like</Text>
              <Text style={styles.buttonText}>{post.likeCount}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>Comment</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      ))}
      <Button title="CreatePost" onPress={() => navigation.navigate('createPost')} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 8,
  },
  post: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  content: {
    fontSize: 16,
    marginBottom: 16,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default Home;
