import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const BuyProducts = () => {
  return (
    <View>
      <Text>BuyProducts</Text>
    </View>
  )
}

export default BuyProducts

const styles = StyleSheet.create({})