import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AppSettings = () => {
  return (
    <View>
      <Text>AppSettings</Text>
    </View>
  )
}

export default AppSettings

const styles = StyleSheet.create({})