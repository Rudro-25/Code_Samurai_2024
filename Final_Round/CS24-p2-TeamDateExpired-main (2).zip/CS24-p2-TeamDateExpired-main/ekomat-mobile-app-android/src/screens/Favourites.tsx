import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Favourites = () => {
  return (
    <View>
      <Text>Favourites</Text>
    </View>
  )
}

export default Favourites

const styles = StyleSheet.create({})