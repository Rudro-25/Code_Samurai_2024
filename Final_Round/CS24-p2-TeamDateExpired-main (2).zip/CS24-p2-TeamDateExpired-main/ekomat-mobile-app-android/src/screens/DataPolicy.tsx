import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const DataPolicy = () => {
  return (
    <View>
      <Text>DataPolicy</Text>
    </View>
  )
}

export default DataPolicy

const styles = StyleSheet.create({})