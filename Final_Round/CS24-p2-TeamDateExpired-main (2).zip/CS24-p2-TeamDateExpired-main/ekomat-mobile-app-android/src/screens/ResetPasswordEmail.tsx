import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ResetPasswordEmail = () => {
  return (
    <View>
      <Text>ResetPasswordEmail</Text>
    </View>
  )
}

export default ResetPasswordEmail

const styles = StyleSheet.create({})