import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import axios from 'axios';

const Messenger = ({navigation}:{navigation:any}) => {
  const [complaint, setComplaint] = useState('');
  const [postType, setPostType] = useState('anonymous');
  const [dropdownVisible, setDropdownVisible] = useState(false);

  const handleDropdownSelect = (value:any) => {
    setPostType(value);
    setDropdownVisible(false);
  };

  const handleSubmit = async () => {
    try {
      // Send a POST request to create a new post
      const response = await axios.post('http://192.168.56.1:8000/complaints', {
        complaintText:complaint,
        type:postType,// Initial like count is set to 0
      });

      // Handle successful response
      console.log('New complaint created:', response.data);

      // Reset input fields after successful creation
      setComplaint('');
      setPostType('');

      // Show success message to the user
      Alert.alert('Success', 'New complaint created successfully!');
    } catch (error) {
      // Handle error
      console.error('Error creating complaint:', error);
      Alert.alert('Error', 'Failed to create complaint. Please try again later.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Complaint:</Text>
      <TextInput
        style={styles.input}
        multiline
        numberOfLines={4}
        value={complaint}
        onChangeText={text => setComplaint(text)}
      />
      <Text style={styles.label}>Type:</Text>
      <TouchableOpacity
        style={styles.dropdown}
        onPress={() => setDropdownVisible(!dropdownVisible)}
      >
        <Text>{postType === 'anonymous' ? 'Anonymous' : 'Unanonymous'}</Text>
        {dropdownVisible && (
          <View style={styles.dropdownContent}>
            <TouchableOpacity onPress={() => handleDropdownSelect('anonymous')}>
              <Text style={styles.dropdownItem}>Anonymous</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleDropdownSelect('unanonymous')}>
              <Text style={styles.dropdownItem}>Unanonymous</Text>
            </TouchableOpacity>
          </View>
        )}
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  label: {
    fontSize: 30,
    marginBottom: 8,
    marginTop: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 8,
    marginBottom: 16,
    fontSize: 16,
    paddingBottom: 30
  },
  dropdown: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 8,
    marginBottom: 16,
  },
  dropdownContent: {
    backgroundColor: '#fff',
    position: 'absolute',
    width: '100%',
    top: '100%',
    left: 0,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    zIndex: 1,
  },
  dropdownItem: {
    padding: 8,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 70
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default Messenger;
