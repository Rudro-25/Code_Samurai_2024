import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const VerificationCode = () => {
  return (
    <View>
      <Text>VerificationCode</Text>
    </View>
  )
}

export default VerificationCode

const styles = StyleSheet.create({})