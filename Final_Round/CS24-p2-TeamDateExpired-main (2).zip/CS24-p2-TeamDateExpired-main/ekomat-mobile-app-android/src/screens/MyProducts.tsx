import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const MyProducts = () => {
  return (
    <View>
      <Text>MyProducts</Text>
    </View>
  )
}

export default MyProducts

const styles = StyleSheet.create({})