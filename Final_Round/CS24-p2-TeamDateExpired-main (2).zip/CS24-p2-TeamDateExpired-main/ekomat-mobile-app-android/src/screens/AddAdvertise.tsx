import { StyleSheet, Text, View, ScrollView } from 'react-native'
import React from 'react'

const AddAdvertise = () => {
  const opportunities = [
    { id: 1, title: 'সাফাইকর্মী', description: 'মুসা প্লেসে সাফাইকর্মী নিয়োগ' },
    { id: 2, title: 'ব্যবসা পরিচালক', description: 'ব্যবসা পরিচালক পদে নিয়োগ চলছে' },
    { id: 3, title: 'স্বেচ্ছা কর্মী', description: 'স্বেচ্ছা কর্মী হিসেবে যোগ দিন' },
    { id: 4, title: 'সাফাই সহযোগী', description: 'গুলসানে সাফাই সহযোগী পদে নিয়োগ চলছে' },
    { id: 5, title: 'কাজের সহযোগী', description: 'কাজের সহযোগী চাই' },
    { id: 6, title: 'অফিস সহকারী', description: 'সিউডায় অফিস সহকারী নিয়োগ চলছে' },
    { id: 7, title: 'স্যালেস প্রতিনিধি', description: 'বাংলাবাজারে স্যালেস প্রতিনিধি পদে নিয়োগ চলছে' },
    { id: 8, title: 'অনুবাদক', description: 'কাছের অনুবাদক চাই' },
    { id: 9, title: 'গার্ড', description: 'বাংলা বিশ্ববিদ্যালয়ে গার্ড পদে নিয়োগ চলছে' },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>নগর পরিষদে নিয়োগ ও স্বেচ্ছা কর্মী অবস্থান</Text>
      {opportunities.map(opportunity => (
        <View key={opportunity.id} style={styles.opportunity}>
          <Text style={styles.title}>{opportunity.title}</Text>
          <Text style={styles.description}>{opportunity.description}</Text>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    paddingTop: 30
  },
  opportunity: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
  },
});

export default AddAdvertise