import { StyleSheet, Text, View } from 'react-native'
import React, { useState } from 'react'
import AppTextInput from '../components/common/AppTextInput'
import { AppButton } from '../components/common/AppButton'
import { signInService } from '../services/http/user/authenticationServices'
import { SignInRequest } from '../models/user/authenticationModels'
import CustomCheckbox from '../components/common/AppCheckBox'
import { TouchableOpacity } from 'react-native-gesture-handler'
import useGetIsLoogedIn from '../hooks/useGetIsLoggedIn'
import { storeInLocalStorage } from '../components/common/ExpoSecureStore'
import axios from 'axios';

const SignIn = ({ navigation }: { navigation: any }) => {

  const [emailOrPhone, setEmailOrPhone] = useState('')
  const [emailOrPhoneError, setEmailOrPhoneError] = useState('')

  const [password, setPassword] = useState('')
  const [passwordError, setPasswordError] = useState('')

  const [rememberMe, setRememberMe] = useState(false)

  const handleSubmit = () => {

    const signInData = new SignInRequest

    signInData.email = emailOrPhone;
    signInData.password = password;

    axios.post('http://192.168.56.1:8000/login',signInData)
    .then((res:any)=>{
      console.log("res", res.data)
      storeInLocalStorage("isLoggedIn", 'true')
        navigation.navigate('profile', { reload: true })
    })
    .catch((err)=> {
      console.log("err", err)
    })
/* 
    signInService(signInData)
      .then((res) => {
        console.log("userDataRes", signInData)
        console.log("signInResponse", res)
        storeInLocalStorage("isLoggedIn", 'true')
        navigation.navigate('profile', { reload: true })
      })
      .catch((err) => {
        console.log("userDataErr", signInData)
        console.log("signInErrorResponse", err.response)
        //setEmailOrPhoneError(err.response.data.errors.EmailOrPhone)
        //setPasswordError(err.response.data.errors.Password)
      }) */
  }

  return (
    <View style={{
      flex: 1,
      backgroundColor: '#E1EFEC',
      justifyContent: "center",
      alignItems: "center"
    }}>
      <Text style={{ fontSize: 20 }}>Sign In To Your Account</Text>
      <Text>Please enter your details{'\n'}{'\n'}{'\n'}</Text>
      <AppTextInput label='Enter Email Or Phone Number' onChange={(e: any) => setEmailOrPhone(e)} errorMessage={emailOrPhoneError} />
      <AppTextInput label='Enter Your Password' type='password' onChange={(e: any) => setPassword(e)} errorMessage={passwordError} />
      <View style={{ flexDirection: 'row' }}>
        <CustomCheckbox label='Remember Me' onChange={() => setRememberMe(!rememberMe)} value={rememberMe} />
        <TouchableOpacity style={{ paddingLeft: 40 }}><Text style={{ color: '#22BB9B' }}>Forgot Password?</Text></TouchableOpacity>
      </View>

      <AppButton text='Login' onPress={() => handleSubmit()} />
      <Text>Don't have an account?<TouchableOpacity><Text style={{ color: '#1975FF', fontWeight: 'bold' }} onPress={() => navigation.navigate('signUp')}>SignUp</Text ></TouchableOpacity></Text>
    </View>
  )
}

export default SignIn;
