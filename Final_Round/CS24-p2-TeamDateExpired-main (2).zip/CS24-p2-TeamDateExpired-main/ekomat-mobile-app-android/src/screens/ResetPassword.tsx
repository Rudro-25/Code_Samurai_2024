import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ResetPassword = () => {
  return (
    <View>
      <Text>ResetPassword</Text>
    </View>
  )
}

export default ResetPassword

const styles = StyleSheet.create({})