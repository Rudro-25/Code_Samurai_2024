import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const TermsOfService = () => {
  return (
    <View>
      <Text>TermsOfService</Text>
    </View>
  )
}

export default TermsOfService

const styles = StyleSheet.create({})