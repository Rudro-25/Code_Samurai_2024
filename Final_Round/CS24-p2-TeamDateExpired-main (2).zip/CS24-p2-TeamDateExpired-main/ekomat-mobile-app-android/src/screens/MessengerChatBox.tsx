import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const MessengerChatBox = () => {
  return (
    <View>
      <Text>MessengerChatBox</Text>
    </View>
  )
}

export default MessengerChatBox

const styles = StyleSheet.create({})