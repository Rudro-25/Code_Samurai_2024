import React, { useState } from 'react';
import { View, TextInput, Button, Alert, TouchableOpacity, Text, StyleSheet } from 'react-native';
import axios from 'axios';

const CreatePostScreen = ({navigation}:{navigation:any}) => {
  const [postText, setPostText] = useState('');
  const [type, setType] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false);

  const handleCreatePost = async () => {
    try {
      // Send a POST request to create a new post
      const response = await axios.post('http://192.168.56.1:8000/posts', {
        postText,
        type,
        likeCount: 0 // Initial like count is set to 0
      });

      // Handle successful response
      console.log('New post created:', response.data);

      // Reset input fields after successful creation
      setPostText('');
      setType('');
      navigation.navigate('home')

      // Show success message to the user
      Alert.alert('Success', 'New post created successfully!');
    } catch (error) {
      // Handle error
      console.error('Error creating post:', error);
      Alert.alert('Error', 'Failed to create post. Please try again later.');
    }
  };

  const toggleDropdown = () => {
    setDropdownVisible(!dropdownVisible);
  };

  const selectType = (selectedType:any) => {
    setType(selectedType);
    setDropdownVisible(false);
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Enter post text"
        value={postText}
        onChangeText={setPostText}
      />
      <TouchableOpacity style={styles.dropdown} onPress={toggleDropdown}>
        <Text style={styles.dropdownText}>Type: {type || 'Select Type'}</Text>
      </TouchableOpacity>
      {dropdownVisible && (
        <View style={styles.dropdownContent}>
          <TouchableOpacity onPress={() => selectType('anonymous')}>
            <Text style={styles.dropdownItem}>Anonymous</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => selectType('unanonymous')}>
            <Text style={styles.dropdownItem}>Unanonymous</Text>
          </TouchableOpacity>
        </View>
      )}
      <Button title="Create Post" onPress={handleCreatePost} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 20,
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  dropdown: {
    width: '100%',
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 5,
    paddingHorizontal: 10,
    justifyContent: 'center',
    marginBottom: 20,
  },
  dropdownText: {
    fontSize: 16,
  },
  dropdownContent: {
    position: 'absolute',
    top: 100,
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 5,
    elevation: 5,
  },
  dropdownItem: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    fontSize: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
});

export default CreatePostScreen;
