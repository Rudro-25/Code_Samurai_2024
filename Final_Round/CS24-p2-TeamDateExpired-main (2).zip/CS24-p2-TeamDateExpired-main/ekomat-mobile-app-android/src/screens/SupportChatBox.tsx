import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SupportChatBox = () => {
  return (
    <View>
      <Text>SupportChatBox</Text>
    </View>
  )
}

export default SupportChatBox

const styles = StyleSheet.create({})