import React from 'react';
import { TouchableOpacity, Text, ActivityIndicator, StyleSheet } from 'react-native';

interface IButtonProps {
    variant?: "text" | "outlined" | "contained" | undefined;
    color?:
    | "inherit"
    | "primary"
    | "secondary"
    | "success"
    | "error"
    | "info"
    | "warning"
    | undefined;
    type?: "submit" | "button" | "reset";
    text?: string | undefined;
    onPress?: () => void;
    style?: any;
    nextPagePath?: string;
    isDisable?: boolean;
    isSubmitting?: boolean;
    isHidden?: boolean;
}

export const AppButton: React.FC<IButtonProps> = ({
    variant,
    type = "button",
    color,
    isHidden,
    text,
    onPress,
    style,
    nextPagePath,
    isDisable,
    isSubmitting
}) => {

    if (nextPagePath) {
        return (
            <TouchableOpacity disabled={isDisable} onPress={onPress} style={{
                paddingVertical: 10,
                paddingHorizontal: 20,
                backgroundColor: 'white',
                borderWidth: 2,
                borderColor: '#006A4E',
                borderRadius: 5,
                alignItems: 'center',
                justifyContent: 'center',
                marginTop: 20,
                marginBottom: 15
            }}>
                <Text>{text}</Text>
            </TouchableOpacity>
        );
    } else {
        return (
            <>
                {!isHidden && (
                    <TouchableOpacity
                        disabled={isDisable || isSubmitting}
                        onPress={onPress}
                        style={{
                            paddingVertical: 10,
                            paddingHorizontal: 20,
                            backgroundColor: 'white',
                            borderWidth: 2,
                            borderColor: '#006A4E',
                            borderRadius: 5,
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginTop: 20,
                            marginBottom: 15
                        }}
                    >
                        {isSubmitting ? (
                            <ActivityIndicator size="small" color="#ffffff" />
                        ) : (
                            <Text>{text}</Text>
                        )}
                    </TouchableOpacity>
                )}
            </>
        );
    }
};
