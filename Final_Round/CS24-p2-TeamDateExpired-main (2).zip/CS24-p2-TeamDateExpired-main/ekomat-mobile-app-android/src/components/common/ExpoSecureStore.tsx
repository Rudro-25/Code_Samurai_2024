import * as SecureStore from 'expo-secure-store';

export const storeInLocalStorage = async (key: any, value: any) => {
    await SecureStore.setItemAsync(key, value);
}

export const getLocalStorageValueByKey = async (key: any) => {
    let result = await SecureStore.getItemAsync(key);
    if (result) {
        //alert(`Local Storage value for key ${key} is:` + result);
        console.log(`Local Storage value for key ${key} is: ` + result)
        return result;
    } else {
        //alert('No values stored under that key');
        console.log(`Local Storage value for key ${key} is: ` + result)
    }
}

export async function getIsLoggedIn(key: any) {
    let data = await getLocalStorageValueByKey(key);
    try {
        return data;
    }
    catch {

    }
}