import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Assuming you're using Expo, if not, adjust the import accordingly

const CustomCheckbox = ({ label, onChange, value }: { label: any, onChange: any, value: any }) => {
  const [isChecked, setIsChecked] = useState(false);

  useEffect(() => {
    setIsChecked(value);
  }, [value]);

  const toggleCheckbox = () => {
    const newValue = !isChecked;
    setIsChecked(newValue);
    if (onChange) {
      onChange(newValue);
    }
  };

  return (
    <TouchableOpacity onPress={toggleCheckbox} style={{ flexDirection: 'row', alignItems: 'center', paddingBottom:20}}>
      <View style={{ width: 24, height: 24, borderWidth: 1, borderRadius: 4, borderColor: 'black', justifyContent: 'center', alignItems: 'center' }}>
        {isChecked && <Ionicons name="checkmark" size={24} color="black" />}
      </View>
      <Text style={{ marginLeft: 8 }}>{label}</Text>
    </TouchableOpacity>
  );
};

export default CustomCheckbox;
