import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';

interface ITextAreaProps {
    value?: string;
    placeholder?: string;
    errorMessage?: string;
    onChange?: (value: string) => void;
    isRequired?: boolean;
    label?: string;
}

export const AppTextArea: React.FC<ITextAreaProps> = ({
    value,
    placeholder,
    onChange,
    errorMessage,
    isRequired,
    label,
}) => {
    const handleChange = (text: string) => {
        if (onChange) onChange(text);
    };

    return (
        <View style={{ flex: 1 }}>
            <Text style={{
                fontSize: 16,
                marginBottom: 5
            }}
            >{label} {isRequired && <Text style={{
                color: 'red',
                fontSize: 12,
            }}>*</Text>}</Text>
            <TextInput
                style={{
                    borderWidth: 2,
                    borderColor: '#006A4E',
                    padding: 10,
                    fontSize: 16,
                    minHeight: 100,
                }}
                onChangeText={handleChange}
                value={value}
                placeholder={placeholder}
                multiline={true}
                numberOfLines={4} // Adjust as needed
            />
            {errorMessage && <Text style={{
                color: 'red',
                fontSize: 12,
            }}>{errorMessage}</Text>}
        </View>
    );
};

