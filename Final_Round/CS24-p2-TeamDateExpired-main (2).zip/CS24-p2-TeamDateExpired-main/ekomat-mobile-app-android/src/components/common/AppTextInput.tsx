import React from 'react';
import { TextInput, Text, View, StyleSheet } from 'react-native';

interface IInputProps {
  label?: string;
  type?: string;
  onChange?: (text: string) => void;
  onKeyDown?: (event: React.KeyboardEvent) => void;
  id?: string;
  placeholder?: string;
  value?: string;
  style?: any;
  errorMessage?: string;
  maxLength?: number;
  isDisabled?: boolean;
  isRequired?: boolean;
}

const AppTextInput: React.FC<IInputProps> = ({
  label,
  type,
  placeholder,
  id,
  onChange,
  onKeyDown,
  value,
  style,
  errorMessage,
  maxLength,
  isDisabled,
  isRequired
}) => {

  const handleChange = (text: string) => {
    if (onChange) {
      onChange(text);
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (onKeyDown) {
      onKeyDown(event);
    }
  };

  return (
    <View>
      <Text style={{ fontSize: 15, paddingBottom: 5 }}>{label} {isRequired && <Text style={{ color: 'red' }}>*</Text>}</Text>
      <View>
        <TextInput
          style={{
            height: 40,
            borderWidth: 2,
            borderColor: '#006A4E',
            borderRadius: 5,
            paddingHorizontal: 10,
            width: 300,
          }}
          onChangeText={handleChange}
          value={value}
          placeholder={placeholder}
          maxLength={maxLength}
          //keyboardType={type as any}
          editable={!isDisabled}
          secureTextEntry={type === 'password'}
        />
      </View>
      <Text style={{ color: 'red' }}>{errorMessage}</Text>
    </View>
  );
};


export default AppTextInput;
