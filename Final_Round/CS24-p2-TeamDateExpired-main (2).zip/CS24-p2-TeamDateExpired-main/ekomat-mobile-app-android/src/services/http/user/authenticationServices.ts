import { SendEmailConfirmationCodeRequest, SendPhoneConfirmationCodeRequest, SignInRequest, SignUpRequest, VerifyEmailConfirmationCodeRequest, VerifyPhoneConfirmationCodeRequest } from "../../../models/user/authenticationModels";
import { GET, POST } from "../httpConfig";

//const url = "/api/v1/Users"
const url = "http://192.168.56.1:8000"

export const signInService = (request: SignInRequest) => {
    return POST(`${url}/login`, request);
};

export const signUpService = (request: SignUpRequest) => {
    return POST(`${url}/signup`, request);
};

export const sendEmailConfirmationCodeService = (request: SendEmailConfirmationCodeRequest) => {
    return POST(`${url}/send-email-confirmation-code`, request);
};

export const verifyEmailConfirmationCodeService = (request: VerifyEmailConfirmationCodeRequest) => {
    return POST(`${url}/verify-email-confirmation-code`, request);
};


export const sendPhoneConfirmationCodeService = (request: SendPhoneConfirmationCodeRequest) => {
    return POST(`${url}/send-phone-confirmation-code`, request);
};

export const verifyPhoneConfirmationCodeService = (request: VerifyPhoneConfirmationCodeRequest) => {
    return POST(`${url}/verify-phone-confirmation-code`, request);
};


export const getUserProfileService = () => {
    return GET(`${url}/getUserProfile`);
};
