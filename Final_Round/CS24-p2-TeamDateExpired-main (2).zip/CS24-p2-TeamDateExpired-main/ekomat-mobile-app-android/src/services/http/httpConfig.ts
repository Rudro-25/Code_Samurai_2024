import axios from 'axios';

export const baseURL = 'https://ibcgudhp9k.execute-api.ap-southeast-1.amazonaws.com'

export const http = axios.create({
    baseURL: baseURL,
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        //'Authorization': `Bearer ${localStorage.getItem('')}`,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Origin, Content-Type, X-XSRF-TOKEN',
    }
})

export function GET(url: string, queryPayload = {}) {
    return http.get(`${baseURL}${url}`, queryPayload);
}

export function POST(url: string, body: any) {
    return http.post(`${baseURL}${url}`, body);
}

export function PUT(url: string, body: any) {
    return http.put(`${baseURL}${url}`, body);
}

export function DELETE(url: string, queryPayload = {}) {
    return http.delete(`${baseURL}${url}`, queryPayload);
}
