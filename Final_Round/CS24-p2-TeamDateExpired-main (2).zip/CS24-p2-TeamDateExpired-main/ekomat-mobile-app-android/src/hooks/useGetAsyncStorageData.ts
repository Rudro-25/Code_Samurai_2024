import { useEffect, useState } from "react";
import { getLocalStorageValueByKey } from "../components/common/ExpoSecureStore";

const useGetAsyncStorageData = (key: any, focused: any, toggler: any) => {
    const [data, setData] = useState('')
    useEffect(() => {
        const fetchData = async () => {
            try {
                const tmp = await getLocalStorageValueByKey(key)
                console.log("asyncStorageData", tmp);
                if (tmp) {
                    setData(tmp);
                }
            } catch (error) {
                console.error('Error fetching data from local storage:', error);
            }
        };
        fetchData();
    }, [focused, toggler]);
    return data;
}

export default useGetAsyncStorageData;