import { useEffect, useState } from "react";
import { getLocalStorageValueByKey } from "../components/common/ExpoSecureStore";

const useGetIsLoogedIn = (key: any, focused: any, toggler: any) => {
    const [isLoggedIn, setisLoggedIn] = useState('')
    useEffect(() => {
        const fetchData = async () => {
            try {
                const tmp = await getLocalStorageValueByKey(key)
                console.log("isLoggedIn", tmp);
                if (tmp) {
                    setisLoggedIn(tmp);
                }
            } catch (error) {
                console.error('Error fetching data from local storage:', error);
            }
        };
        fetchData();
    }, [focused, toggler]);
    return isLoggedIn;
}

export default useGetIsLoogedIn;