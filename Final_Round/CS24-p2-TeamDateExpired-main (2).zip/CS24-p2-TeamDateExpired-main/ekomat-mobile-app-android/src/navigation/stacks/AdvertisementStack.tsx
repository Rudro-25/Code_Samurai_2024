import { createStackNavigator } from '@react-navigation/stack';
import AddAdvertise from '../../screens/AddAdvertise';

const Stack = createStackNavigator();

function AdvertisementStack() {
  return (
    <Stack.Navigator initialRouteName='addAdvertise' screenOptions={{ headerShown: false }}>
      <Stack.Screen name="addAdvertise" component={AddAdvertise} />
    </Stack.Navigator>
  );
}

export default AdvertisementStack;