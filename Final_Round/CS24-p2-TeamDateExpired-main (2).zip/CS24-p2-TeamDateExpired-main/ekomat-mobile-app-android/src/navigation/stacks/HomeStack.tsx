import { createStackNavigator } from '@react-navigation/stack';
import Home from '../../screens/Home';
import ProductDetails from '../../screens/ProductDetails';
import SplashScreen from '../../screens/SplashScreen';
import CreatePostScreen from '../../screens/CreatePost';

const Stack = createStackNavigator();

function HomeStack() {
  return (
    <Stack.Navigator initialRouteName='splash' screenOptions={{ headerShown: false }}>
      <Stack.Screen name="splash" component={SplashScreen} />
      <Stack.Screen name="home" component={Home} />
      <Stack.Screen name="productDetails" component={ProductDetails} />
      <Stack.Screen name="createPost" component={CreatePostScreen} />

    </Stack.Navigator>
  );
}

export default HomeStack;