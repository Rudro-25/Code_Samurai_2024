import { createStackNavigator } from '@react-navigation/stack';
import Messenger from '../../screens/Messenger';

const Stack = createStackNavigator();

function MessengerStack() {
  return (
    <Stack.Navigator initialRouteName='messenger' screenOptions={{ headerShown: false }}>
      <Stack.Screen name="messenger" component={Messenger} />
    </Stack.Navigator>
  );
}

export default MessengerStack;