import { createStackNavigator } from '@react-navigation/stack';
import EditProfile from '../../screens/EditProfile';
import Profile from '../../screens/Profile';
import SignIn from '../../screens/SignIn';
import SignUp from '../../screens/SignUp';

const Stack = createStackNavigator();

function ProfileStack() {
  return (
    <Stack.Navigator initialRouteName='profile' screenOptions={{ headerShown: false }}>
      <Stack.Screen name="profile" component={Profile} />
      <Stack.Screen name="editProfile" component={EditProfile} />
      <Stack.Screen name="signIn" component={SignIn} />
      <Stack.Screen name="signUp" component={SignUp} />
    </Stack.Navigator>
  );
}

export default ProfileStack;