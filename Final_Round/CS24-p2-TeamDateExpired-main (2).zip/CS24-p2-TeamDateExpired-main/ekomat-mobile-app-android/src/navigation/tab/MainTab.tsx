import { Image } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeStack from '../stacks/HomeStack';
import AdvertisementStack from '../stacks/AdvertisementStack';
import MessengerStack from '../stacks/MessengerStack';
import ProfileStack from '../stacks/ProfileStack';
import { useState } from 'react';

const Tab = createBottomTabNavigator();

function MainTab() {

    return (
        <Tab.Navigator
            screenOptions={{
                headerShown: false,
                tabBarLabelStyle: { fontSize: 15 },
                tabBarStyle: { height: 75, backgroundColor: "#E1EFEC" },
                tabBarActiveTintColor: "#22BB9B",
                tabBarActiveBackgroundColor: "#D8E6E2"
            }}>
            <Tab.Screen
                name="Home"
                component={HomeStack}
                options={{
                    tabBarIcon: () => (
                        <Image source={require('../../../assets/home.png')}
                            style={{ width: 45, height: 45 }} />
                    )
                }} />
            <Tab.Screen
                name="Opportunities"
                component={AdvertisementStack}
                options={{
                    tabBarIcon: () => (
                        <Image source={require('../../../assets/add-advertise.png')} style={{ width: 45, height: 45 }} />
                    )
                }} />
            <Tab.Screen
                name="Complain Box"
                component={MessengerStack}
                options={{
                    tabBarIcon: () => (
                        <Image source={require('../../../assets/message.png')} style={{ width: 45, height: 45 }} />
                    )
                }} />
            <Tab.Screen
                name="Profile"
                component={ProfileStack}
                options={{
                    tabBarIcon: () => (
                        <Image source={require('../../../assets/profile.png')} style={{ width: 45, height: 45 }} />
                    )
                }} />
        </Tab.Navigator>
    );
}

export default MainTab;