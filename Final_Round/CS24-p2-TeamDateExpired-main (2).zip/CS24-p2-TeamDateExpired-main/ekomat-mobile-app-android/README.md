Packages to be installed for IOS: 
    pods via Cocoapods: npx pod-install ios