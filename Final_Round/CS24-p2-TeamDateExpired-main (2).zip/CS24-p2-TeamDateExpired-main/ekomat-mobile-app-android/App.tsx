import { NavigationContainer } from '@react-navigation/native';
import MainTab from './src/navigation/tab/MainTab';

export default function App() {
  return (
    <NavigationContainer>
      <MainTab />
    </NavigationContainer>
  );
}

