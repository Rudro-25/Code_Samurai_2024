import React, { useState, useEffect } from 'react';
import './EmployeeList.css'; // Import your CSS file for styling
import { useNavigate } from 'react-router';

const EmployeeList = () => {

    const navigate = useNavigate();
    const [employees, setEmployees] = useState([]);

    useEffect(() => {
        // Fetch employees data from backend API
        fetchEmployees();
    }, []);

    const fetchEmployees = async () => {
        try {
            // Fetch employees data from your backend API
            const response = await fetch('http://localhost:8000/employees'); // Update the URL as per your API endpoint
            const data = await response.json();
            setEmployees(data); // Assuming data is an array of employee objects
        } catch (error) {
            console.error('Error fetching employees:', error);
        }
    };

    return (
        <div className="employee-list-container">
            <h2>Employee List</h2>
            <button onClick={()=>navigate('/createEmployee')}>Create Employee</button>
            <table className="employee-table">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Full Name</th>
                        <th>Date of Birth</th>
                        <th>Date of Hire</th>
                        <th>Job Title</th>
                        <th>Payment Rate per Hour</th>
                        <th>Contact Information</th>
                        <th>Assigned Collection Route</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map((employee) => (
                        <tr key={employee._id}>
                            <td>{employee.employeeId}</td>
                            <td>{employee.fullName}</td>
                            <td>{employee.dateOfBirth}</td>
                            <td>{employee.dateOfHire}</td>
                            <td>{employee.jobTitle}</td>
                            <td>{employee.paymentRatePerHour}</td>
                            <td>{employee.contactInformation}</td>
                            <td>{employee.assignedCollectionRoute}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default EmployeeList;
