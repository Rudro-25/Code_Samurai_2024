import React from 'react';
import './LandfillListPage.css';

// Sample data for landfill list
const landfillListData = [
  { id: 1, name: 'Landfill 1', capacity: '1000', operationTime: '9:00 AM - 5:00 PM', managers: ['Manager 1', 'Manager 2'], location: 'Coordinates 1' },
  { id: 2, name: 'Landfill 2', capacity: '2000', operationTime: '8:00 AM - 6:00 PM', managers: ['Manager 3', 'Manager 4'], location: 'Coordinates 2' },
  // Add more data as needed
];

function LandfillListPage() {
  return (
    <div className="landfill-list-page-container">
      <h2>Landfill List</h2>
      <table className="landfill-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Capacity</th>
            <th>Operation Time</th>
            <th>Managers</th>
            <th>Location</th>
          </tr>
        </thead>
        <tbody>
          {landfillListData.map(landfill => (
            <tr key={landfill.id}>
              <td>{landfill.name}</td>
              <td>{landfill.capacity}</td>
              <td>{landfill.operationTime}</td>
              <td>{landfill.managers.join(', ')}</td>
              <td>{landfill.location}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default LandfillListPage;
