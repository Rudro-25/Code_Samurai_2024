import React, { useState } from 'react';
import './AddVehiclePage.css';

function AddVehiclePage() {
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [type, setType] = useState('');
  const [capacity, setCapacity] = useState('');
  const [fuelCostLoaded, setFuelCostLoaded] = useState('');
  const [fuelCostUnloaded, setFuelCostUnloaded] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with registrationNumber:", registrationNumber, "type:", type, "capacity:", capacity, "fuelCostLoaded:", fuelCostLoaded, "fuelCostUnloaded:", fuelCostUnloaded);
  };

  return (
    <div className="add-vehicle-page-container">
      <h2>Add Vehicle</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="registrationNumber">Registration Number:</label>
          <input
            type="text"
            id="registrationNumber"
            value={registrationNumber}
            onChange={(e) => setRegistrationNumber(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="type">Type:</label>
          <input
            type="text"
            id="type"
            value={type}
            onChange={(e) => setType(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="capacity">Capacity:</label>
          <input
            type="text"
            id="capacity"
            value={capacity}
            onChange={(e) => setCapacity(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="fuelCostLoaded">Fuel Cost per Kilometer - Fully Loaded:</label>
          <input
            type="text"
            id="fuelCostLoaded"
            value={fuelCostLoaded}
            onChange={(e) => setFuelCostLoaded(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="fuelCostUnloaded">Fuel Cost per Kilometer - Unloaded:</label>
          <input
            type="text"
            id="fuelCostUnloaded"
            value={fuelCostUnloaded}
            onChange={(e) => setFuelCostUnloaded(e.target.value)}
            required
          />
        </div>
        <button type="submit">Add Vehicle</button>
      </form>
    </div>
  );
}

export default AddVehiclePage;
