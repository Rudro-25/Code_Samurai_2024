import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './STSListPage.css'; // Import CSS file for styling
import { useNavigate } from 'react-router';

const STSList = () => {
  const [stsList, setSTSList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchSTSList = async () => {
      try {
        const response = await axios.get('http://localhost:8000/sts');
        setSTSList(response.data);
      } catch (error) {
        console.error('Error fetching STS list:', error);
      }
    };

    fetchSTSList();
  }, []);

  return (
    <div className="container">
      <h2>STS List</h2>
      <button onClick={() => navigate('/createSts')}>Create STS</button>
      <table>
        <thead>
          <tr>
            <th>Ward</th>
            <th>Capacity</th>
            <th>Latitude</th>
            <th>Longitude</th>
            <th>Managers</th>
            <th>Vehicles</th>
          </tr>
        </thead>
        <tbody>
          {stsList.map((sts, index) => (
            <tr key={index}>
              <td>{sts.ward}</td>
              <td>{sts.capacity}</td>
              <td>{sts.latitude}</td>
              <td>{sts.longitude}</td>
              <td>{sts.managers.join(', ')}</td>
              <td>{sts.vehicles.join(', ')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default STSList;
