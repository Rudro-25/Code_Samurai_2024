import React, { useState } from 'react';
import './ContractorForm.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CreateContractor = () => {

    const navigate = useNavigate();

    const resetForm = () => {
        const nullFormData = {
            name: null,
            contractId: null,
            regId: null,
            regDate: null,
            tin: null,
            phone: null,
            workforcesSize: null,
            pmntPrTnWst: null,
            rqrdWstPrDay: null,
            cntrctDur: null,
            areaOfCllctn: null
        };
        setFormData(nullFormData);
    };

    const [formData, setFormData] = useState({
        name: '',
        regId: '',
        regDate: '',
        tin: '',
        phone: '',
        workforcesSize: 0,
        pmntPrTnWst: 0,
        rqrdWstPrDay: 0,
        cntrctDur: '',
        areaOfCllctn: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Send form data to backend API for creation
        // You can use Axios or fetch API for making HTTP requests
        console.log(formData);

        axios.post("http://localhost:8000/createContractor", formData).then(function (response) {
            // handle success
            console.log(response);
            navigate('/adminHome')
            resetForm();

        })
            .catch(function (error) {
                // handle error
                console.log(error);
            })

        // Add your API call here to submit the form data
    };

    return (
        <div className="contractor-form-container">
            <h2>Create Contractor</h2>
            <form onSubmit={handleSubmit} className="contractor-form">
                <div className="form-group">
                    <label>Name:</label>
                    <input type="text" name="name" value={formData.name} onChange={handleChange} />
                </div>
                {/* Add other form fields here */}

                <div className="form-group">
                    <label>Registration ID:</label>
                    <input type="text" name="regId" value={formData.regId} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Registration Date:</label>
                    <input type="date" name="regDate" value={formData.regDate} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>TIN:</label>
                    <input type="text" name="tin" value={formData.tin} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Phone:</label>
                    <input type="tel" name="phone" value={formData.phone} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Workforce Size:</label>
                    <input type="number" name="workforcesSize" value={formData.workforcesSize} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Payment Per Ton Waste:</label>
                    <input type="number" name="pmntPrTnWst" value={formData.pmntPrTnWst} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Required Waste Per Day:</label>
                    <input type="number" name="rqrdWstPrDay" value={formData.rqrdWstPrDay} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Contract Duration:</label>
                    <input type="text" name="cntrctDur" value={formData.cntrctDur} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Area of Collection:</label>
                    <input type="text" name="areaOfCllctn" value={formData.areaOfCllctn} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <button type="submit">Create Contractor</button>
                </div>
            </form>
        </div>
    );
};

export default CreateContractor;
