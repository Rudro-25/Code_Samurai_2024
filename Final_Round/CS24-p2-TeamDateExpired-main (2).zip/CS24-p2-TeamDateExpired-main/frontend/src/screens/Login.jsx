import React, { useState } from 'react';
import "./Login.css"
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = () => {
    // Logic for login goes here
    axios.post('http://localhost:8000/login', { email: email, password: password })
      .then(response => {
        console.log(response.data.user.userRoleId.name);

        // Store userId, roleName, and roleId in local storage
        localStorage.setItem('userId', response.data.user._id);
        localStorage.setItem('roleName', response.data.user.userRoleId.name);
        localStorage.setItem('roleId', response.data.user.userRoleId._id);


        if (response.data.user.userRoleId.name === "Admin") {
          navigate("/adminHome")
        }
        else if (response.data.user.userRoleId.name === "STS Manager") {
          navigate("/stsManagerHome")
        }
        else if (response.data.user.userRoleId.name === "Landfill Manager") {
          navigate("/landfillManagerHome")
        }
        // You can perform additional actions after successful deletion, if needed
      })
      .catch(error => {
        console.error(error);
        // Handle error
      })
  };
  return (
    <div className="login-container">
      <h2>Login</h2>
   {/*    <p>Admin Master Password</p>
      <p>Email: admin@gmail.com</p>
      <p>Password: 123123</p> */}
      <form>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={handleEmailChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={handlePasswordChange}
            required
          />
        </div>
        <button type="button" onClick={handleLogin}>Login</button>
      </form>
      <p>Don't have an account? <a href="/signUp">Sign Up</a></p>
    </div>
  );
}
