import React, { useState } from 'react';
import './CreateRole.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function CreateRole() {

  const navigate = useNavigate();
  const [name, setName] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:8000/createUserRole", {
      name: name
    }).then(function (response) {
      // handle success
      console.log(response);
      setName("")
      navigate('/adminHome')
    })
      .catch(function (error) {
        // handle error
        console.log(error);
      })

    // Submit form logic
    //console.log("Submitting form with name:", name);
  };

  return (
    <div className="role-creation-form-container">
      <h2>Create Role</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <button type="submit">Create Role</button>
      </form>
    </div>
  );
}

export default CreateRole;
