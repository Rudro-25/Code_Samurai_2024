import React, { useState } from 'react'
import "./AdminHome.css"
import { useNavigate } from 'react-router-dom';


export const AdminHome = () => {
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = () => {
    // Handle logout logic
    console.log("Logging out...");
    navigate("/")
  };

  return (
    <div className="admin-home-page">
      <nav className="navbar">
        <div className="navbar-left">
          <h1>Admin Home</h1>
        </div>
        <div className="navbar-right">
          <div className="profile-icon" onClick={toggleDropdown}>
            <span>Profile</span>
            {isDropdownOpen && (
              <div className="dropdown-content">
                <a href="#">Profile</a>
                <a href="#" onClick={handleLogout}>Log Out</a>
              </div>
            )}
          </div>
        </div>
      </nav>
      <div className="admin-content">
        <div className="box manage-sts" onClick={() => navigate('/createRole')}>
          <h2>Create Role</h2>
        </div>
        <div className="box manage-landfill" onClick={() => navigate('/createUser')}>
          <h2>Create User</h2>
        </div>
        <div className="box manage-users" onClick={() => navigate('/userList')}>
          <h2>User List</h2>
        </div>
        <div className="box manage-userss" onClick={() => navigate('/contractorList')}>
          <h2>Contractor List</h2>
        </div>
        <div className="box manage-userser" onClick={() => navigate('/contractManagerList')}>
          <h2>Contractor Manager List</h2>
        </div>
        <div className="box manage-sadfg" onClick={() => navigate('/employeeList')}>
          <h2>Employee List</h2>
        </div>
        <div className="box manage-sadfg" onClick={() => navigate('/workHourLogList')}>
          <h2>Work Hour Log</h2>
        </div>
       
       
        <div className="box dashboard-statisticsasdg" onClick={() => navigate('/stsList')}>
          <h2>STS List</h2>
        </div>
       
        <div className="box dashboard-statisticsryh" onClick={() => navigate('/BillView')}>
          <h2>Bill View</h2>
        </div>
        <div className="box dashboard-statisticsryh" onClick={() => navigate('/complaintList')}>
          <h2>Complaints</h2>
        </div>
      </div>
    </div>
  )
}
