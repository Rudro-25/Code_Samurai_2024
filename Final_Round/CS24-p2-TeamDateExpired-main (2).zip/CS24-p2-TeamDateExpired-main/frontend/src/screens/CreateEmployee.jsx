import React, { useState } from 'react';
import './CreateEmployee.css'; // Import your CSS file for styling
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CreateEmployee = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        employeeId: '',
        fullName: '',
        dateOfBirth: '',
        dateOfHire: '',
        jobTitle: '',
        paymentRatePerHour: '',
        contactInformation: '',
        assignedCollectionRoute: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Send form data to backend API for creation
        // You can use Axios or fetch API for making HTTP requests
        console.log(formData);
        axios.post("http://localhost:8000/createEmployee", formData).then(function (response) {
            // handle success
            console.log(response);
            navigate('/adminHome')

        })
            .catch(function (error) {
                // handle error
                console.log(error);
            })
        // Add your API call here to submit the form data
    };

    return (
        <div className="create-employee-container">
            <h2>Create Employee</h2>
            <form onSubmit={handleSubmit} className="create-employee-form">
                <div className="form-group">
                    <label>Employee ID:</label>
                    <input type="text" name="employeeId" value={formData.employeeId} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Full Name:</label>
                    <input type="text" name="fullName" value={formData.fullName} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Date of Birth:</label>
                    <input type="date" name="dateOfBirth" value={formData.dateOfBirth} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Date of Hire:</label>
                    <input type="date" name="dateOfHire" value={formData.dateOfHire} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Job Title:</label>
                    <input type="text" name="jobTitle" value={formData.jobTitle} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Payment Rate per Hour:</label>
                    <input type="number" name="paymentRatePerHour" value={formData.paymentRatePerHour} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Contact Information:</label>
                    <input type="text" name="contactInformation" value={formData.contactInformation} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Assigned Collection Route:</label>
                    <input type="text" name="assignedCollectionRoute" value={formData.assignedCollectionRoute} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <button type="submit">Create Employee</button>
                </div>
            </form>
        </div>
    );
};

export default CreateEmployee;
