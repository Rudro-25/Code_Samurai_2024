import React, { useState } from 'react';
import './LandfillManagerHome.css';
import { useNavigate } from 'react-router-dom';

function LandfillManagerHome() {
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = () => {
    // Handle logout logic
    console.log("Logging out...");
    navigate("/")
  };

  return (
    <div className="landfill-manager-home-page">
      <nav className="navbar">
        <div className="navbar-left">
          <h1>Landfill Manager Home</h1>
        </div>
        <div className="navbar-right">
          <div className="profile-icon" onClick={toggleDropdown}>
            <span>Profile</span>
            {isDropdownOpen && (
              <div className="dropdown-content">
                <a href="#">Profile</a>
                <a href="#" onClick={handleLogout}>Log Out</a>
              </div>
            )}
          </div>
        </div>
      </nav>
      <div className="landfill-content">
        <div className="box manage-landfill">
          <h2>Manage Landfill</h2>
        </div>
      </div>
    </div>
  );
}

export default LandfillManagerHome;
