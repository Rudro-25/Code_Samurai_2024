import React, { useEffect, useState } from 'react';
import './UserLIst.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function UserLIst() {
  const navigate = useNavigate();
  const [userList, setUserList] = useState([])
  useEffect(() => {

    axios.get('http://localhost:8000/userList') // Assuming your API endpoint is '/api/users'
      .then(response => {
        // Set the received data to the state
        setUserList(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });

  }, [])


  const handleUpdate = (userId) => {
    // Logic for updating user
    console.log("Updating user with id:", userId);
    navigate(`/updateUser/${userId}`)
  };

  const handleDelete = (userId) => {
    // Logic for deleting user
    axios.delete(`http://localhost:8000/deleteUser/${userId}`)
      .then(response => {
        console.log('User deleted successfully');
        navigate('/adminHome')
        // You can perform additional actions after successful deletion, if needed
      })
      .catch(error => {
        console.error('Error deleting user:', error);
        // Handle error
      })
    console.log("Deleting user with id:", userId);
  };

  const handleAssignPermission = (userId) => {
    // Logic for assigning permission
    console.log("Assigning permission to user with id:", userId);
  };

  return (
    <div className="user-list-container">
      <h2>User List</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {userList.map(user => (
            <tr key={user.id}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.userRoleId?.name}</td>
              <td>
                <button className="update" onClick={() => handleUpdate(user._id)}>Update</button>
                <button className="delete" onClick={() => handleDelete(user._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default UserLIst;
