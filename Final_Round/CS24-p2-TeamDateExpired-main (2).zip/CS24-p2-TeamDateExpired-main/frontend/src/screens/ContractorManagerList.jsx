import React, { useState, useEffect } from 'react';
import './ContractorManagerList.css'; // Import your CSS file for styling
import { useNavigate } from 'react-router';

const ContractorManagerList = () => {

    const navigate = useNavigate();

    const [contractorManagers, setContractorManagers] = useState([]);

    useEffect(() => {
        // Fetch contractor managers data from backend API
        fetchContractorManagers();
    }, []);

    const fetchContractorManagers = async () => {
        try {
            // Fetch contractor managers data from your backend API
            const response = await fetch('http://localhost:8000/contractorManagers'); // Update the URL as per your API endpoint
            const data = await response.json();
            setContractorManagers(data); // Assuming data is an array of contractor manager 
        } catch (error) {
            console.error('Error fetching contractor managers:', error);
        }
    };

    return (
        <div className="contractor-manager-list-container">
            <h2>Contractor Manager List</h2>
            <button onClick={()=>navigate('/createContractManager')}>Create Contractor</button>
            <table className="contractor-manager-table">
                <thead>
                    <tr>
                        <th>Full Name</th>
                        <th>Email Address</th>
                        <th>Contact Number</th>
                        <th>Assigned Contractor Company</th>
                        <th>Access Level</th>
                    </tr>
                </thead>
                <tbody>
                    {contractorManagers.map((manager) => (
                        <tr key={manager._id}>
                            <td>{manager.fullName}</td>
                            <td>{manager.emailAddress}</td>
                            <td>{manager.contactNumber}</td>
                            <td>{manager.assignedContractorCompany}</td>
                            <td>{manager.accessLevel}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ContractorManagerList;
