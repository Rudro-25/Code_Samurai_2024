import React, { useState } from 'react';
import axios from 'axios';
import "./stsEntry.css"

const AddSTSEntry = () => {
    const [formData, setFormData] = useState({
        timeAndDateOfCollection: '',
        amountOfWasteCollected: '',
        contractorId: '',
        typeOfWasteCollected: '',
        designatedSTS: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8000/stsentries', formData);
            console.log(response.data);
            // Optionally, you can redirect the user to another page or display a success message
        } catch (error) {
            console.error('Error adding STS entry:', error);
            // Optionally, you can display an error message to the user
        }
    };

    return (
        <div className="container">
            <h2>Add STS Entry</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Time and Date of Collection:</label>
                    <input type="datetime-local" name="timeAndDateOfCollection" value={formData.timeAndDateOfCollection} onChange={handleChange} required />
                </div>
                <div>
                    <label>Amount of Waste Collected (kg):</label>
                    <input type="number" name="amountOfWasteCollected" value={formData.amountOfWasteCollected} onChange={handleChange} required />
                </div>
                <div>
                    <label>Contractor ID:</label>
                    <input type="text" name="contractorId" value={formData.contractorId} onChange={handleChange} required />
                </div>
                <div>
                    <label>Type of Waste Collected:</label>
                    <select name="typeOfWasteCollected" value={formData.typeOfWasteCollected} onChange={handleChange} required>
                        <option value="">Select type</option>
                        <option value="Domestic">Domestic</option>
                        <option value="Plastic">Plastic</option>
                        <option value="Construction Waste">Construction Waste</option>
                    </select>
                </div>
                <div>
                    <label>Designated STS for Deposit:</label>
                    <input type="text" name="designatedSTS" value={formData.designatedSTS} onChange={handleChange} required />
                </div>
                <button type="submit">Add STS Entry</button>
            </form>
        </div>
    );
};

export default AddSTSEntry;
