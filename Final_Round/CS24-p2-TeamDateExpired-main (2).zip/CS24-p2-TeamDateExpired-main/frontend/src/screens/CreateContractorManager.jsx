import React, { useState } from 'react';
import './CreateContractorManager.css'; // Import your CSS file for styling
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CreateContractorManager = () => {

    const navigate = useNavigate();

    const resetForm = () => {
        const nullFormData = {
            name: null,
            contractId: null,
            regId: null,
            regDate: null,
            tin: null,
            phone: null,
            workforcesSize: null,
            pmntPrTnWst: null,
            rqrdWstPrDay: null,
            cntrctDur: null,
            areaOfCllctn: null
        };
        setFormData(nullFormData);
    };

    const [formData, setFormData] = useState({
        fullName: '',
        userId: '',
        emailAddress: '',
        contactNumber: '',
        assignedContractorCompany: '',
        accessLevel: 'manager',
        username: '',
        password: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Send form data to backend API for creation
        // You can use Axios or fetch API for making HTTP requests
        console.log(formData);
        axios.post("http://localhost:8000/createContractorManager", formData).then(function (response) {
            // handle success
            console.log(response);
            navigate('/adminHome')
            resetForm();

        })
            .catch(function (error) {
                // handle error
                console.log(error);
            })

        // Add your API call here to submit the form data
    };

    return (
        <div className="create-contractor-manager-container">
            <h2>Create Contractor Manager</h2>
            <form onSubmit={handleSubmit} className="create-contractor-manager-form">
                <div className="form-group">
                    <label>Full Name:</label>
                    <input type="text" name="fullName" value={formData.fullName} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>User ID:</label>
                    <input type="text" name="userId" value={formData.userId} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Email Address:</label>
                    <input type="email" name="emailAddress" value={formData.emailAddress} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Contact Number:</label>
                    <input type="text" name="contactNumber" value={formData.contactNumber} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Assigned Contractor Company:</label>
                    <input type="text" name="assignedContractorCompany" value={formData.assignedContractorCompany} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Access Level:</label>
                    <select name="accessLevel" value={formData.accessLevel} onChange={handleChange}>
                        <option value="Level 1">Level 1</option>
                        <option value="Level 2">Level 2</option>
                        <option value="Level 3">Level 3</option>
                    </select>
                </div>
                <div className="form-group">
                    <label>Username:</label>
                    <input type="text" name="username" value={formData.username} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Password:</label>
                    <input type="password" name="password" value={formData.password} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <button type="submit">Create Contractor Manager</button>
                </div>
            </form>
        </div>
    );
};

export default CreateContractorManager;
