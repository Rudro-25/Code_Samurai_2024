import React, { useEffect, useState } from 'react';
import './ContractorList.css';
import { useNavigate } from 'react-router';

const ContractorList = ({}) => {

    const navigate = useNavigate();

    const [contractors, setContractors] = useState([]);

    useEffect(() => {
        // Fetch contractors data from backend API
        fetchContractors();
    }, []);

    const fetchContractors = async () => {
        try {
            // Fetch contractors data from your backend API
            const response = await fetch('http://localhost:8000/contractors');
            const data = await response.json();
            setContractors(data); // Assuming data is an array of contractor objects
        } catch (error) {
            console.error('Error fetching contractors:', error);
        }
    };

    return (
        <div className="contractor-list-container">
             <button onClick={()=>navigate('/createContractor')}>Create Contractor</button>
            <h1>Contractor List</h1>
           
            <table className="contractor-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Registration ID</th>
                    </tr>
                </thead>
                <tbody>
                    {contractors.map((contractor) => (
                        <tr key={contractor._id}>
                            <td>{contractor.name}</td>
                            <td>{contractor.phone}</td>
                            <td>{contractor.regId}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ContractorList;
