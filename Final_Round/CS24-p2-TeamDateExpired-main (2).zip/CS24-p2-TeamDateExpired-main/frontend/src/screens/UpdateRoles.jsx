import React, { useState } from 'react';
import './UpdateRoles.css';

function UpdateRoles() {
  const [name, setName] = useState('');
  const [permissions, setPermissions] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with name:", name, "and permissions:", permissions);
  };

  return (
    <div className="role-update-form-container">
      <h2>Update Role</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="permissions">Permissions:</label>
          <select
            id="permissions"
            value={permissions}
            onChange={(e) => setPermissions(e.target.value)}
            required
          >
            <option value="">Select Permissions</option>
            <option value="read">Read</option>
            <option value="write">Write</option>
            <option value="delete">Delete</option>
          </select>
        </div>
        <button type="submit">Update Role</button>
      </form>
    </div>
  );
}

export default UpdateRoles;
