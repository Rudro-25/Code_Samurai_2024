import React, { useEffect, useState } from 'react';
import './UpdateUser.css';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


function UpdateUser() {
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [userRole, setUserRole] = useState('');

  const { userId } = useParams();

  useEffect(() => {
    axios.get(`http://localhost:8000/users/${userId}`) // Assuming your API endpoint is '/api/users'
      .then(response => {
        // Set the received data to the state
        console.log(response)
        setName(response.data?.name)
        setEmail(response.data?.email)
      setUserRole(response.data.userRoleId?._id)
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, [])


  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    axios.put(`http://localhost:8000/updateUsers/${userId}`,{
      name:name,
      email:email,
      userRoleId:userRole

    }) // Assuming your API endpoint is '/api/users'
    .then(response => {
      // Set the received data to the state
      navigate('/adminHome')
      console.log(response)

    })
    .catch(error => {
      console.error('Error fetching data:', error);
    });
  };

  return (
    <div className="user-update-form-container">
      <h2>User Update Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        {/*  <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div> */}
        <div className="form-group">
          <label htmlFor="userRole">User Role:</label>
          <select id="userRole" value={userRole} onChange={(e) => setUserRole(e.target.value)} required>
            <option value="">Select User Role</option>
            <option value="66093a2afcabfed766820639">Admin</option>
            <option value="66093a31fcabfed76682063b">STS Manager</option>
            <option value="66093a38fcabfed76682063d">Landfill Manager</option>
          </select>
        </div>
        <button type="submit">Update User</button>
      </form>
    </div>
  );
}

export default UpdateUser;
