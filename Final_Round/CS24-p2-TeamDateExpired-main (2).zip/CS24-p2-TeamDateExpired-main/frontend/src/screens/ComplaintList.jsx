import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ComplaintList.css';

const ComplaintList = () => {
  const [complaints, setComplaints] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8000/complaints');
        setComplaints(response.data);
      } catch (error) {
        console.error('Error fetching complaints:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="container">
      <h2 className="header">Complaint List</h2>
      {complaints.length === 0 ? (
        <p>No complaints found</p>
      ) : (
        <div className="complaints">
          {complaints.map(complaint => (
            <div key={complaint._id} className="complaint">
              <p className="complaintText">{complaint.complaintText}</p>
              <p className="complaintType">Type: {complaint.type}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ComplaintList;
