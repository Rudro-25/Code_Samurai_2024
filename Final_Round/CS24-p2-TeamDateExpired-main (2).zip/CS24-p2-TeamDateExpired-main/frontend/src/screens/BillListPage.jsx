import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import './BView.css';

const BillListPage = () => {
    const [contractors, setContractors] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:8000/billView');
                const fetchedContractors = response.data;
                const updatedContractors = fetchedContractors.map(contractor => ({
                    ...contractor,
                    amountOfWasteCollected: Math.floor(Math.random() * 1000)
                }));
                setContractors(updatedContractors);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();
    }, []);

    const generateBill = (rowData) => {
        const { contractId, pmntPrTnWst, rqrdWstPrDay, amountOfWasteCollected } = rowData;
        const billAmount = (amountOfWasteCollected * pmntPrTnWst) - rqrdWstPrDay;

        // Create a new jsPDF instance
        const doc = new jsPDF();

        // Add bill information to the PDF
        doc.text(`Contract ID: ${contractId}`, 10, 10);
        doc.text(`Payment Per Ton Waste: ${pmntPrTnWst}`, 10, 20);
        doc.text(`Required Waste Per Day: ${rqrdWstPrDay}`, 10, 30);
        doc.text(`Total Amount of Waste Collected: ${amountOfWasteCollected}`, 10, 40);
        doc.text(`Total Bill: ${billAmount}`, 10, 50);

        // Save the PDF
        doc.save(`${contractId}_bill.pdf`);
    };

    return (
        <div>
            <h1>Billing View</h1>
            <table>
                <thead>
                    <tr>
                        <th>Contract ID</th>
                        <th>Payment Per Ton Waste</th>
                        <th>Required Waste Per Day</th>
                        <th>Total Amount of Waste Collected</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {contractors.map(contractor => (
                        <tr key={contractor._id}>
                            <td>{contractor.contractId}</td>
                            <td>{contractor.pmntPrTnWst}</td>
                            <td>{contractor.rqrdWstPrDay}</td>
                            <td>{contractor.amountOfWasteCollected}</td>
                            <td>
                                <button onClick={() => generateBill(contractor)}>
                                    Generate Bill
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default BillListPage;
