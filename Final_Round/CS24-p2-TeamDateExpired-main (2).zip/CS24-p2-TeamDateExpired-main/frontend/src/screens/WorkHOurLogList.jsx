import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./WorkHOurLogList.css"
import { useNavigate } from 'react-router';

const WorkHourLogList = () => {
    const [workHourLogs, setWorkHourLogs] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:8000/workhourlogs');
                setWorkHourLogs(response.data);
            } catch (error) {
                console.error('Error fetching work hour logs:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div className="container">
            <h2>Work Hour Log List</h2>
            <button onClick={()=>navigate('/createWorkHourLog')}>Create Work Hour Log</button>
            <table>
                <thead>
                    <tr>
                        <th>Worker ID</th>
                        <th>Log In Time</th>
                        <th>Log Out Time</th>
                        <th>Overtime Hours</th>
                        <th>Absent Days</th>
                        <th>Leave Days</th>
                    </tr>
                </thead>
                <tbody>
                    {workHourLogs.map((log, index) => (
                        <tr key={index}>
                            <td>{log.workerId}</td>
                            <td>{new Date(log.logInTime).toLocaleString()}</td>
                            <td>{new Date(log.logOutTime).toLocaleString()}</td>
                            <td>{log.overtimeHours}</td>
                            <td>{log.absentDays}</td>
                            <td>{log.leaveDays}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default WorkHourLogList;
