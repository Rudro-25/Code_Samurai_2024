import React, { useState } from 'react';
import './AssignLandfillManagerPage.css';

function AssignLandfillManagerPage() {
  const [landfillId, setLandfillId] = useState('');
  const [managerIds, setManagerIds] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with landfillId:", landfillId, "managerIds:", managerIds);
  };

  return (
    <div className="assign-landfill-manager-page-container">
      <h2>Assign Landfill Managers</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="landfillId">Landfill ID:</label>
          <input
            type="text"
            id="landfillId"
            value={landfillId}
            onChange={(e) => setLandfillId(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="managerIds">Landfill Manager IDs (comma-separated):</label>
          <input
            type="text"
            id="managerIds"
            value={managerIds}
            onChange={(e) => setManagerIds(e.target.value.split(",").map(id => id.trim()))}
            required
          />
        </div>
        <button type="submit">Assign Managers</button>
      </form>
    </div>
  );
}

export default AssignLandfillManagerPage;
