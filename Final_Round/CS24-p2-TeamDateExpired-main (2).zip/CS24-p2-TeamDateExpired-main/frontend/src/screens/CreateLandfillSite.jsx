import React, { useState } from 'react';
import './CreateLandfillSitePage.css';

function CreateLandfillSitePage() {
  const [name, setName] = useState('');
  const [capacity, setCapacity] = useState('');
  const [operationalTimespan, setOperationalTimespan] = useState('');
  const [coordinates, setCoordinates] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit form logic
    console.log("Submitting form with name:", name, "capacity:", capacity, "operationalTimespan:", operationalTimespan, "coordinates:", coordinates);
  };

  return (
    <div className="create-landfill-site-page-container">
      <h2>Create Landfill Site</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="capacity">Capacity:</label>
          <input
            type="text"
            id="capacity"
            value={capacity}
            onChange={(e) => setCapacity(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="operationalTimespan">Operational Timespan:</label>
          <input
            type="text"
            id="operationalTimespan"
            value={operationalTimespan}
            onChange={(e) => setOperationalTimespan(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="coordinates">GPS Coordinates:</label>
          <input
            type="text"
            id="coordinates"
            value={coordinates}
            onChange={(e) => setCoordinates(e.target.value)}
            required
          />
        </div>
        <button type="submit">Create Landfill Site</button>
      </form>
    </div>
  );
}

export default CreateLandfillSitePage;
