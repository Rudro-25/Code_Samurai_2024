import React, { useState } from 'react';
import axios from 'axios';
import './CreateSTS.css'; // Import CSS file for styling
import { useNavigate } from 'react-router';

const CreateSTS = () => {

  const navigate = useNavigate();

    const [formData, setFormData] = useState({
        ward: '',
        capacity: '',
        latitude: '',
        longitude: '',
        managers: '',
        vehicles: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8000/sts', formData);
            console.log(response.data);
            navigate('/adminHome')
            // Optionally, you can redirect the user to another page or display a success message
        } catch (error) {
            console.error('Error creating STS entry:', error);
            // Optionally, you can display an error message to the user
        }
    };

    return (
        <div className="container">
            <h2>Create STS Entry</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Ward:</label>
                    <input type="number" name="ward" value={formData.ward} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Capacity:</label>
                    <input type="number" name="capacity" value={formData.capacity} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Latitude:</label>
                    <input type="text" name="latitude" value={formData.latitude} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Longitude:</label>
                    <input type="text" name="longitude" value={formData.longitude} onChange={handleChange} required />
                </div>
               {/*  <div className="form-group">
                    <label>Managers:</label>
                    <input type="text" name="managers" value={formData.managers} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Vehicles:</label>
                    <input type="text" name="vehicles" value={formData.vehicles} onChange={handleChange} required />
                </div> */}
                <button type="submit">Create STS Entry</button>
            </form>
        </div>
    );
};

export default CreateSTS;
