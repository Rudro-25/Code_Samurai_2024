import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./stsEntryList.css"
const STSEntryList = () => {
    const [stsEntries, setSTSEntries] = useState([]);

    useEffect(() => {
        const fetchSTSEntries = async () => {
            try {
                const response = await axios.get('http://localhost:8000/stsentries');
                setSTSEntries(response.data);
            } catch (error) {
                console.error('Error fetching STS entries:', error);
            }
        };

        fetchSTSEntries();
    }, []);

    return (
        <div className="container">
            <h2>STS Entry List</h2>
            <table>
                <thead>
                    <tr>
                        <th>Time and Date of Collection</th>
                        <th>Amount of Waste Collected (kg)</th>
                        <th>Contractor ID</th>
                        <th>Type of Waste Collected</th>
                        <th>Designated STS</th>
                        <th>Vehicle Used for Transportation</th>
                    </tr>
                </thead>
                <tbody>
                    {stsEntries.map((entry, index) => (
                        <tr key={index}>
                            <td>{new Date(entry.timeAndDateOfCollection).toLocaleString()}</td>
                            <td>{entry.amountOfWasteCollected}</td>
                            <td>{entry.contractorId}</td>
                            <td>{entry.typeOfWasteCollected}</td>
                            <td>{entry.designatedSTS}</td>
                            <td>{entry.vehicleUsedForTransportation}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default STSEntryList;
