import React, { useState } from 'react';
import axios from 'axios';
import './CreateWorkHourLog.css'
import { useNavigate } from 'react-router';

const CreateWorkHourLog = () => {

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        workerId: '',
        logInTime: '',
        logOutTime: '',
        overtimeHours: '',
        absentDays: '',
        leaveDays: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8000/workhourlogs', formData);
            console.log(response.data);
            navigate('/adminHome')
            // Optionally, you can redirect the user to another page or display a success message
        } catch (error) {
            console.error('Error creating work hour log:', error);
            // Optionally, you can display an error message to the user
        }
    };

    return (
        <div className="container">
            <h2>Create Work Hour Log</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Worker ID:</label>
                    <input type="text" name="workerId" value={formData.workerId} onChange={handleChange} required />
                </div>
                <div>
                    <label>Log In Time:</label>
                    <input type="datetime-local" name="logInTime" value={formData.logInTime} onChange={handleChange} required />
                </div>
                <div>
                    <label>Log Out Time:</label>
                    <input type="datetime-local" name="logOutTime" value={formData.logOutTime} onChange={handleChange} required />
                </div>
                <div>
                    <label>Overtime Hours:</label>
                    <input type="number" name="overtimeHours" value={formData.overtimeHours} onChange={handleChange} required />
                </div>
                <div>
                    <label>Absent Days:</label>
                    <input type="number" name="absentDays" value={formData.absentDays} onChange={handleChange} required />
                </div>
                <div>
                    <label>Leave Days:</label>
                    <input type="number" name="leaveDays" value={formData.leaveDays} onChange={handleChange} required />
                </div>
                <button type="submit">Create Work Hour Log</button>
            </form>
        </div>
    );
};

export default CreateWorkHourLog;
