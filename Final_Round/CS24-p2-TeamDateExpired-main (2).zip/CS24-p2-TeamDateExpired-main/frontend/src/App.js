import React from "react";
import Login from "./screens/Login";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import SignUp from "./screens/SignUp";
import { AdminHome } from "./screens/AdminHome";
import CreateUser from "./screens/CreateUser";
import LandfillManagerHome from "./screens/LandfillManagerHome";
import StsManagerHome from "./screens/StsManagerHome";
import UserLIst from "./screens/UserLIst";
import UpdateUser from "./screens/UpdateUser";
import CreateRole from "./screens/CreateRole";
import UpdateRoles from "./screens/UpdateRoles";
import CreatePermissioin from "./screens/CreatePermissioin";
import AddVehiclePage from "./screens/AddVehicle";
import CreateSTSPage from "./screens/CreateSts";
import AssignSTSManagerPage from "./screens/AssignStsManager";
import AssignTrucksToSTSPage from "./screens/AssingTrckSts";
import CreateLandfillSitePage from "./screens/CreateLandfillSite";
import AssignLandfillManagerPage from "./screens/AssingLndfMngr";
import STSListPage from "./screens/StsList";
import LandfillListPage from "./screens/LanfFillLIstPage";
import VehicleListPage from "./screens/VehicleLIst";
import CreateContractor from "./screens/CreateContractor";
import ContractorList from "./screens/Contractorlist";
import CreateContractorManager from "./screens/CreateContractorManager";
import ContractorManagerList from "./screens/ContractorManagerList";
import EmployeeList from "./screens/EmployeeList";
import CreateEmployee from "./screens/CreateEmployee";
import CreateWorkHourLog from "./screens/CreateWorkHourLog";
import WorkHourLogList from "./screens/WorkHOurLogList";
import AddSTSEntry from "./screens/stsEntry";
import STSEntryList from "./screens/stsEntriyList";
import BillListPage from "./screens/BillListPage";
import ComplaintList from "./screens/ComplaintList";

function App() {
  const route = createBrowserRouter([
    {
      path: "/",
      element: <Login />
    },
    {
      path: "/signUp",
      element: <SignUp />
    },
    {
      path: "/adminHome",
      element: <AdminHome />
    },
    {
      path: "/createUser",
      element: <CreateUser />
    },
    {
      path: "/landfillManagerHome",
      element: <LandfillManagerHome />
    },
    {
      path: "/stsManagerHome",
      element: <StsManagerHome />
    },
    {
      path: "/userList",
      element: <UserLIst />
    },
    {
      path: "/updateUser/:userId",
      element: <UpdateUser />
    },
    {
      path: "/createRole",
      element: <CreateRole />
    },
    {
      path: "/updateRole/:roleId",
      element: <UpdateRoles />
    },
    {
      path: "/createPermissoin",
      element: <CreatePermissioin />
    },
    {
      path: "/addVehicle",
      element: <AddVehiclePage />
    },
    {
      path: "/createSts",
      element: < CreateSTSPage />
    },
    {
      path: "/stsList",
      element: < STSListPage />
    },
    {
      path: "/assignStsMngr",
      element: < AssignSTSManagerPage />
    },
    {
      path: "/assignTrckSts",
      element: < AssignTrucksToSTSPage />
    },
    {
      path: "/createLandfillSite",
      element: < CreateLandfillSitePage />
    },
    {
      path: "/assignLndflMngr",
      element: < AssignLandfillManagerPage />
    },

    {
      path: "/addVehicleSts",
      element: < AddVehiclePage />
    },
    {
      path: "/stsList",
      element: < STSListPage />
    },
    {
      path: "/landfillList",
      element: < LandfillListPage />
    },
    {
      path: "/vehicleLIst",
      element: < VehicleListPage />
    },
    {
      path: "/createContractor",
      element: < CreateContractor />
    },
    {
      path: "/contractorList",
      element: < ContractorList />
    },
    {
      path: "/createContractManager",
      element: < CreateContractorManager />
    },
    {
      path: "/contractManagerList",
      element: < ContractorManagerList />
    },
    {
      path: "/createEmployee",
      element: < CreateEmployee />
    },
    {
      path: "/employeeList",
      element: < EmployeeList />
    },
    {
      path: "/createWorkHourLog",
      element: < CreateWorkHourLog />
    },
    {
      path: "/workHourLogList",
      element: < WorkHourLogList />
    },
    {
      path: "/stsEntry",
      element: < AddSTSEntry />
    },
    {
      path: "/stsEntryList",
      element: < STSEntryList />
    },
    {
      path: "/BillView",
      element: < BillListPage />
    },
    {
      path: "/complaintList",
      element: < ComplaintList />
    },




  ])
  return (
    <>
      <RouterProvider router={route} />
    </>
  );
}

export default App;
