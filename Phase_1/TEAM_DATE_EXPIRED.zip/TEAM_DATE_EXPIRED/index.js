const e = require('express');
const express = require('express');
const app = express();
const mongoose = require('mongoose');

const port = 8000;
app.use(express.json());

mongoose.connect('mongodb+srv://rumman:codesamurai123123@cluster0.e1ywht2.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(async () => {
        console.log('Connected to MongoDB');

        // Delete all data from the 'users', 'stations', and 'trains' collections
        await Promise.all([
            User.deleteMany({}),
            Station.deleteMany({}),
            Train.deleteMany({})
        ]);

        // Start the Express server after data deletion
        app.listen(port, () => {
            console.log(`Server is running on http://localhost:${port}`);
        });
    })
    .catch((err) => console.error('Error connecting to MongoDB:', err));



//routes
//create user
app.post('/api/users', async (req, res) => {
    try {
        const usersToAdd = Array.isArray(req.body) ? req.body : [req.body]; // Convert to array if not already

        // Create an array to store the promises returned by save() for each book
        const savePromises = usersToAdd.map(async userData => {
            const newUser = new User({
                user_id: userData.user_id,
                user_name: userData.user_name,
                balance: userData.balance,
            });
            await newUser.save();
            const savedUserData = {
                user_id: newUser.user_id,
                user_name: newUser.user_name,
                balance: newUser.balance,
                // Add more fields if needed
            };
            return savedUserData;
        });
        const savedUser = await Promise.all(savePromises);
        res.status(201).json(savedUser[0]);
    } catch (error) {
        console.error('Error adding users:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

//creat Station
app.post('/api/stations', async (req, res) => {
    try {
        const stationsToAdd = Array.isArray(req.body) ? req.body : [req.body]; // Convert to array if not already

        // Create an array to store the promises returned by save() for each book
        const savePromises = stationsToAdd.map(async stationData => {
            const newStation = new Station({
                station_id: stationData.station_id,
                station_name: stationData.station_name,
                longitude: stationData.longitude,
                latitude: stationData.latitude,
            });
            await newStation.save();
            const savedStationData = {
                station_id: newStation.station_id,
                station_name: newStation.station_name,
                longitude: newStation.longitude,
                latitude: newStation.latitude,
                // Add more fields if needed
            };
            return savedStationData;
        });

        // Wait for all books to be saved
        const savedStation = await Promise.all(savePromises);

        res.status(201).json(savedStation[0]);
    } catch (error) {
        console.error('Error adding stations:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

//createTrain
app.post('/api/trains', async (req, res) => {
    try {
        const trainToAdd = Array.isArray(req.body) ? req.body : [req.body]; // Convert to array if not already

        // Create an array to store the promises returned by save() for each book
        const savePromises = trainToAdd.map(async trainData => {
            const newTrain = new Train({
                train_id: trainData.train_id,
                train_name: trainData.train_name,
                capacity: trainData.capacity,
                stops: trainData.stops.map(stop => ({
                    station_id: stop.station_id,
                    arrival_time: stop.arrival_time,
                    departure_time: stop.departure_time,
                    fare: stop.fare
                }))
            });
            await newTrain.save();
            const savedTrainData = {
                train_id: newTrain.train_id,
                train_name: newTrain.train_name,
                capacity: newTrain.capacity,
                stops: newTrain.stops.map(stop => ({
                    station_id: stop.station_id,
                    arrival_time: stop.arrival_time,
                    departure_time: stop.departure_time,
                    fare: stop.fare
                }))
                // Add more fields if needed
            };
            return savedTrainData;
        });

        // Wait for all books to be saved
        const savedTrain = await Promise.all(savePromises);

        let serviceStart = null;
        let serviceEnd = null;

        const numStations = savedTrain[0].stops.length;

        savedTrain[0].stops.forEach(stop => {
            if (stop.departure_time && (!serviceStart || stop.departure_time < serviceStart)) {
                serviceStart = stop.departure_time;
            }
            if (stop.arrival_time && (!serviceEnd || stop.arrival_time > serviceEnd)) {
                serviceEnd = stop.arrival_time;
            }
        });

        res.status(201).json({
            "train_id": savedTrain[0].train_id,
            "train_name": savedTrain[0].train_name,
            "capacity": savedTrain[0].capacity,
            "service_start": serviceStart,
            "service_ends": serviceEnd,
            "num_stations": numStations
        });

    } catch (error) {
        console.error('Error adding train:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


//getStations
app.get('/api/stations', async (req, res) => {
    const stationData = await Station.find().sort({ station_id: 1 }).select('-_id -__v');
    res.status(200).json({ "stations": stationData })
})

//getTrainsByStationId
app.get('/api/stations/:station_id/trains', async (req, res) => {

    const stationId = req.params.station_id;

    const station = await Station.findOne({ station_id: stationId });

    if (station) {
        try {

            const trains = await Train.find(
                { 'stops': { $elemMatch: { station_id: stationId } } },
                { 'stops.$': 1, train_id: 1, _id: 0 }
            ).select('-_id -__v -capacity');
            // Assuming trains is an array of Train objects retrieved from the database
            const transformedTrains = trains.map(train => ({
                train_id: train.train_id, // Assuming train_id is available in the train object
                arrival_time: train.stops[0].arrival_time,
                departure_time: train.stops[0].departure_time
            }));

            // Create the final transformed response object
            const transformedResponse = {
                station_id: stationId,
                trains: transformedTrains
            };
            res.status(200).json(transformedResponse);

        } catch (error) {
            console.error("Error fetching trains:", error);
            res.status(500).json({ "error": "Internal Server Error" });
        }
    }
    else {
        res.status(404).send({
            "message": `station with id: ${stationId} was not found`
        })
    }


});
//wallet
app.get('/api/wallets/:wallet_id', async (req, res) => {
    const user_id = req.params.wallet_id;
    const userData = await User.find({ user_id: user_id }).select('-_id -__v');
    if (userData.length == 1) {
        res.status(200).json({
            "wallet_id": user_id,
            "balance": userData[0].balance,
            "wallet_user":
            {
                "user_id": user_id,
                "user_name": userData[0].user_name
            }
        })
    }
    else {
        res.status(404).json({
            "message": `wallet with id: ${user_id} was not found`
        })
    }

})

//addwallet
app.put("/api/wallets/:wallet_id", async (req, res) => {
    const balance = req.body.recharge;
    if (balance >= 100 && balance <= 10000) {
        const user_id = req.params.wallet_id;
        const userData = await User.find({ user_id: user_id }).select('-_id -__v');
        if (userData.length == 1) {
            const oldBlance = userData[0].balance;
            const user = await User.findOneAndUpdate({ user_id: user_id }, { balance: oldBlance + balance }, { new: true });
            res.status(200).json({
                "wallet_id": user_id,
                "balance": oldBlance + balance,
                "wallet_user":
                {
                    "user_id": user_id,
                    "user_name": userData[0].user_name
                }
            })
        }
        else {
            res.status(404).json({
                "message": `wallet with id: ${user_id} was not found`
            })
        }
    }
    else {
        res.status(400).json({
            "message": `invalid amount: ${balance}`
        })
    }
})

//Ticket
app.get("/api/tickets", async (req, res) => {
    const trains = await Train.find();
    res.status(200).json(trains)
})

//Models
//User
const userSchema = new mongoose.Schema({
    user_id: {
        type: Number
    },
    user_name: {
        type: String
    },
    balance: {
        type: Number
    }
});

const User = new mongoose.model('UserModel', userSchema);
//station
const stationSchema = new mongoose.Schema({
    station_id: {
        type: Number
    },
    station_name: {
        type: String
    },
    longitude: {
        type: Number
    },
    latitude: {
        type: Number
    }
});

const Station = new mongoose.model('StationModel', stationSchema);

//train
const trainSchema = new mongoose.Schema({
    train_id: {
        type: Number
    },
    train_name: {
        type: String
    },
    capacity: {
        type: Number
    },
    stops: [
        {
            station_id: {
                type: Number
            },
            arrival_time: {
                type: String
            },
            departure_time: {
                type: String
            },
            fare: {
                type: Number
            }

        }
    ]
});

const Train = new mongoose.model('TrainModel', trainSchema);